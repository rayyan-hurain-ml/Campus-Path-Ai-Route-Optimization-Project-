"""
Genetic Algorithm — Delivery Route Optimizer
============================================
Course topic: Evolutionary computation / optimization
Use case: Find a near-optimal visit order for multiple campus delivery stops

Problem modeled as TSP (Traveling Salesperson Problem):
  - Given N stops on a grid, find the order that minimizes total travel distance
  - Start and end at the depot (first stop)

Chromosome representation:
  - Permutation of stop indices [0, 1, 2, ..., n-1]

Genetic operators:
  1. Initialization — random permutations
  2. Fitness — inverse of total Manhattan route distance
  3. Selection — tournament selection
  4. Crossover — order crossover (OX)
  5. Mutation — swap two random genes
  6. Elitism — keep best individual each generation

Time complexity: O(generations * population * n^2) for distance calculations
"""

from __future__ import annotations

import random
import time
from dataclasses import dataclass

from .graph import manhattan_distance


@dataclass
class GAResult:
    """Return type for genetic algorithm optimization."""

    best_route: list[tuple[int, int]]
    best_order: list[int]
    total_distance: float
    naive_distance: float
    fitness_history: list[float]
    generations: int
    population_size: int
    time_ms: float


def route_distance(stops: list[tuple[int, int]], order: list[int]) -> float:
    """
    Compute total Manhattan distance for visiting stops in `order`.
    Route is cyclic: return to depot after last stop.
    """
    if len(order) < 2:
        return 0.0

    total = 0.0
    for i in range(len(order) - 1):
        total += manhattan_distance(stops[order[i]], stops[order[i + 1]])
    total += manhattan_distance(stops[order[-1]], stops[order[0]])
    return total


def fitness(stops: list[tuple[int, int]], order: list[int]) -> float:
    """Higher fitness = shorter route. Avoid division by zero."""
    dist = route_distance(stops, order)
    return 1.0 / (1.0 + dist)


def create_individual(n: int, rng: random.Random) -> list[int]:
    """Random permutation of stop indices."""
    genes = list(range(n))
    rng.shuffle(genes)
    return genes


def tournament_select(
    population: list[list[int]],
    stops: list[tuple[int, int]],
    k: int,
    rng: random.Random,
) -> list[int]:
    """Pick the best of k random individuals."""
    contenders = rng.sample(population, min(k, len(population)))
    return max(contenders, key=lambda ind: fitness(stops, ind))


def order_crossover(parent_a: list[int], parent_b: list[int], rng: random.Random) -> list[int]:
    """
    Order Crossover (OX) preserves permutation validity.
    Copy a slice from parent A, fill remaining slots from parent B in order.
    """
    n = len(parent_a)
    if n < 2:
        return parent_a[:]

    start, end = sorted(rng.sample(range(n), 2))
    child = [-1] * n
    child[start : end + 1] = parent_a[start : end + 1]

    fill = [gene for gene in parent_b if gene not in child]
    idx = 0
    for i in range(n):
        if child[i] == -1:
            child[i] = fill[idx]
            idx += 1

    return child


def mutate(individual: list[int], mutation_rate: float, rng: random.Random) -> list[int]:
    """Swap mutation: exchange two random positions with probability `mutation_rate`."""
    if rng.random() > mutation_rate or len(individual) < 2:
        return individual

    i, j = rng.sample(range(len(individual)), 2)
    individual[i], individual[j] = individual[j], individual[i]
    return individual


def optimize_delivery_route(
    stops: list[tuple[int, int]],
    population_size: int = 80,
    generations: int = 150,
    mutation_rate: float = 0.15,
    seed: int | None = 42,
) -> GAResult:
    """
    Evolve a population to minimize delivery route distance.

    Args:
        stops: List of (row, col) delivery locations; index 0 is depot.
        population_size: Number of individuals per generation.
        generations: Number of evolutionary iterations.
        mutation_rate: Probability of swap mutation per offspring.
        seed: Random seed for reproducible demos.

    Returns:
        GAResult with best route, fitness history, and comparison to naive order.
    """
    if len(stops) < 2:
        raise ValueError("At least 2 stops are required (depot + one delivery).")

    t0 = time.perf_counter()
    rng = random.Random(seed)
    n = len(stops)

    # Naive baseline: visit in the order the user clicked
    naive_order = list(range(n))
    naive_distance = route_distance(stops, naive_order)

    # Initialize population
    population = [create_individual(n, rng) for _ in range(population_size)]
    fitness_history: list[float] = []

    best_individual = max(population, key=lambda ind: fitness(stops, ind))

    for _ in range(generations):
        # Track best fitness each generation for charting
        gen_best = max(population, key=lambda ind: fitness(stops, ind))
        if fitness(stops, gen_best) > fitness(stops, best_individual):
            best_individual = gen_best[:]
        fitness_history.append(fitness(stops, gen_best))

        # Elitism: carry best individual to next generation
        next_population = [best_individual[:]]

        while len(next_population) < population_size:
            parent_a = tournament_select(population, stops, k=3, rng=rng)
            parent_b = tournament_select(population, stops, k=3, rng=rng)
            child = order_crossover(parent_a, parent_b, rng)
            child = mutate(child, mutation_rate, rng)
            next_population.append(child)

        population = next_population

    best_order = best_individual
    best_dist = route_distance(stops, best_order)
    best_route = [stops[i] for i in best_order]

    elapsed = (time.perf_counter() - t0) * 1000
    return GAResult(
        best_route=best_route,
        best_order=best_order,
        total_distance=round(best_dist, 2),
        naive_distance=round(naive_distance, 2),
        fitness_history=[round(f, 6) for f in fitness_history],
        generations=generations,
        population_size=population_size,
        time_ms=round(elapsed, 3),
    )
