"""Pydantic schemas for CampusPath AI API requests and responses."""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field


class Point(BaseModel):
    """Grid coordinate (row, col)."""

    row: int = Field(ge=0)
    col: int = Field(ge=0)


class PathfindRequest(BaseModel):
    """Request body for pathfinding endpoints."""

    grid: list[list[int]]
    start: Point
    end: Point
    algorithm: Literal["bfs", "dfs", "astar", "all"] = "all"


class PathfindMetrics(BaseModel):
    """Performance metrics for one pathfinding run."""

    algorithm: str
    found: bool
    path_length: int
    nodes_expanded: int
    time_ms: float
    path: list[Point]
    visited_order: list[Point]


class PathfindResponse(BaseModel):
    """Response for single or compare-all pathfinding."""

    results: list[PathfindMetrics]
    optimal_path_length: int | None = None


class DeliveryRequest(BaseModel):
    """Request body for genetic algorithm delivery optimization."""

    stops: list[Point]
    population_size: int = Field(default=80, ge=10, le=300)
    generations: int = Field(default=150, ge=20, le=500)
    mutation_rate: float = Field(default=0.15, ge=0.01, le=0.5)
    seed: int | None = 42


class DeliveryResponse(BaseModel):
    """Optimized delivery route result."""

    best_route: list[Point]
    best_order: list[int]
    total_distance: float
    naive_distance: float
    improvement_percent: float
    fitness_history: list[float]
    generations: int
    population_size: int
    time_ms: float


class CourseInput(BaseModel):
    id: str
    name: str
    teacher: str
    enrollment: int = Field(ge=1)


class RoomInput(BaseModel):
    id: str
    name: str
    capacity: int = Field(ge=1)


class SlotInput(BaseModel):
    day: str
    slot: str
    label: str


class TimetableRequest(BaseModel):
    """Custom timetable CSP input."""

    courses: list[CourseInput]
    rooms: list[RoomInput]
    slots: list[SlotInput]


class AssignmentOutput(BaseModel):
    course_id: str
    course_name: str
    teacher: str
    day: str
    slot: str
    slot_label: str
    room_id: str
    room_name: str


class TimetableResponse(BaseModel):
    found: bool
    assignments: list[AssignmentOutput]
    satisfied_constraints: list[str]
    time_ms: float
    nodes_explored: int
