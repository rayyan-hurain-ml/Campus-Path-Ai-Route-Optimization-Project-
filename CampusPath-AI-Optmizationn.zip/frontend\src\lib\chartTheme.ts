/** Shared Recharts dark-theme colors (neon dashboard style) */

export const CHART = {
  grid: "rgba(255,255,255,0.06)",
  axis: "#64748b",
  tooltipBg: "rgba(12,16,24,0.95)",
  tooltipBorder: "rgba(0,242,234,0.2)",
  cyan: "#00f2ea",
  magenta: "#ff007a",
  lime: "#a3ff00",
  orange: "#ff8c42",
  cyanGlow: "rgba(0,242,234,0.4)",
  magentaGlow: "rgba(255,0,122,0.4)",
};

export const tooltipStyle = {
  backgroundColor: CHART.tooltipBg,
  border: `1px solid ${CHART.tooltipBorder}`,
  borderRadius: 12,
  color: "#e2e8f0",
  fontSize: 12,
};
