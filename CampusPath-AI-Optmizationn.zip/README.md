# CampusPath AI

**AI-Based Intelligent System for Solving Real-World Problems**

CampusPath AI solves three university challenges using five AI algorithms, with live visualization:

1. **Navigation** — shortest walkable path (BFS, DFS, A*)
2. **Delivery** — multi-stop route optimization (Genetic Algorithm)
3. **Timetabling** — conflict-free class schedule (CSP)

Open the app and use the **Guide & Help** tab for full explanation.

---

## Algorithms

| # | Algorithm | File | Use Case |
|---|-----------|------|----------|
| 1 | **BFS** | `backend/app/algorithms/bfs.py` | Shortest path (unweighted grid) |
| 2 | **DFS** | `backend/app/algorithms/dfs.py` | Deep exploration / maze search |
| 3 | **A\*** | `backend/app/algorithms/astar.py` | Optimal path with fewer expanded nodes |
| 4 | **Genetic Algorithm** | `backend/app/algorithms/genetic_algorithm.py` | Multi-stop delivery route (TSP) |
| 5 | **CSP Backtracking** | `backend/app/algorithms/csp_timetable.py` | Conflict-free class timetable |

---

## Project Structure

```
campuspath-ai/
├── backend/                 # Python FastAPI + all AI algorithms
│   ├── app/
│   │   ├── algorithms/      # BFS, DFS, A*, GA, CSP
│   │   ├── api/routes.py
│   │   ├── models/schemas.py
│   │   └── main.py
│   └── requirements.txt
├── frontend/                # React dashboard
└── README.md
```

---

## How to Run

### Prerequisites

- Python 3.11+
- Node.js 18+

### Backend

```powershell
cd backend
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```

API docs: http://localhost:8000/docs

### Frontend

```powershell
cd frontend
npm install
npm run dev
```

App: http://localhost:5173

---

## How to Use

### Pathfinding Lab

1. Select **Obstacle** mode → click cells to draw walls
2. Select **Start** / **End** → place green start and red goal
3. Click **Compare All** → see BFS vs DFS vs A*
4. Use **Load CASE Campus** for a pre-built map

### Delivery Optimizer

1. Click grid to add delivery stops (first = depot)
2. Adjust GA sliders
3. Click **Run Genetic Algorithm**

### Timetable Scheduler

1. Click **Load CASE Islamabad Sample & Solve**
2. View conflict-free timetable grid

---

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/health` | Health check |
| POST | `/api/pathfind` | Run BFS / DFS / A* / all |
| POST | `/api/delivery/optimize` | Genetic Algorithm route |
| GET | `/api/timetable/sample` | Sample timetable |
| POST | `/api/timetable/solve` | Custom CSP input |
