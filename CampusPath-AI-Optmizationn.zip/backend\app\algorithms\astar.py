"""
A* (A-Star) Search Pathfinding
==============================
Course topic: Informed / heuristic search
Use case: Optimal campus navigation with fewer expanded nodes than BFS

How it works:
1. Maintain open set prioritized by f(n) = g(n) + h(n)
   - g(n) = cost from start to n (steps taken)
   - h(n) = heuristic estimate from n to goal (Manhattan distance)
2. Repeatedly expand the node with lowest f(n)
3. When goal is expanded, reconstruct optimal path

Why A* is efficient:
  - With an admissible heuristic, A* is optimal
  - Expands fewer nodes than BFS by steering search toward the goal

Time complexity: O(E log V) with binary heap (typical grid case)
Space complexity: O(V)
"""

from __future__ import annotations

import heapq
import time

from .graph import (
    PathResult,
    manhattan_distance,
    neighbors,
    reconstruct_path,
    validate_grid_request,
)


def astar(
    grid: list[list[int]],
    start: tuple[int, int],
    end: tuple[int, int],
) -> PathResult:
    """
    Run A* search from `start` to `end` using Manhattan heuristic.
    """
    validate_grid_request(grid, start, end)
    t0 = time.perf_counter()

    # Priority queue entries: (f_score, tie_breaker, node)
    counter = 0
    open_heap: list[tuple[float, int, tuple[int, int]]] = []
    heapq.heappush(open_heap, (manhattan_distance(start, end), counter, start))

    g_score: dict[tuple[int, int], float] = {start: 0.0}
    came_from: dict[tuple[int, int], tuple[int, int] | None] = {start: None}
    visited_order: list[tuple[int, int]] = []
    nodes_expanded = 0
    closed: set[tuple[int, int]] = set()

    while open_heap:
        _, _, current = heapq.heappop(open_heap)

        if current in closed:
            continue

        closed.add(current)
        nodes_expanded += 1
        visited_order.append(current)

        if current == end:
            elapsed = (time.perf_counter() - t0) * 1000
            path = reconstruct_path(came_from, start, end)
            return PathResult(
                path=path,
                visited_order=visited_order,
                nodes_expanded=nodes_expanded,
                time_ms=round(elapsed, 3),
                found=True,
            )

        for nxt in neighbors(current, grid):
            tentative_g = g_score[current] + 1.0

            if nxt not in g_score or tentative_g < g_score[nxt]:
                g_score[nxt] = tentative_g
                f_score = tentative_g + manhattan_distance(nxt, end)
                came_from[nxt] = current
                counter += 1
                heapq.heappush(open_heap, (f_score, counter, nxt))

    elapsed = (time.perf_counter() - t0) * 1000
    return PathResult(
        path=[],
        visited_order=visited_order,
        nodes_expanded=nodes_expanded,
        time_ms=round(elapsed, 3),
        found=False,
    )
