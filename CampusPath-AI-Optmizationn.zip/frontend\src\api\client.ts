/**
 * API Client — CampusPath AI Frontend
 * ====================================
 * All HTTP calls to the FastAPI backend go through this file.
 *
 * Environment:
 *   VITE_API_URL — backend base URL (default http://localhost:8000)
 *
 * Flow:
 *   UI component → api/client.ts → FastAPI → Python algorithms → JSON response
 */

/** Grid cell coordinate sent to / received from the backend */
export interface Point {
  row: number;
  col: number;
}

/** Metrics for one pathfinding algorithm run */
export interface PathfindMetrics {
  algorithm: string;
  found: boolean;
  path_length: number;
  nodes_expanded: number;
  time_ms: number;
  path: Point[];
  visited_order: Point[];
}

export interface PathfindResponse {
  results: PathfindMetrics[];
  optimal_path_length: number | null;
}

export interface DeliveryResponse {
  best_route: Point[];
  best_order: number[];
  total_distance: number;
  naive_distance: number;
  improvement_percent: number;
  fitness_history: number[];
  generations: number;
  population_size: number;
  time_ms: number;
}

export interface Assignment {
  course_id: string;
  course_name: string;
  teacher: string;
  day: string;
  slot: string;
  slot_label: string;
  room_id: string;
  room_name: string;
}

export interface TimetableResponse {
  found: boolean;
  assignments: Assignment[];
  satisfied_constraints: string[];
  time_ms: number;
  nodes_explored: number;
}

/** Read API base URL from Vite env (set in Vercel dashboard for production) */
const API_BASE = import.meta.env.VITE_API_URL ?? "http://localhost:8000";

async function request<T>(path: string, options?: RequestInit): Promise<T> {
  const response = await fetch(`${API_BASE}${path}`, {
    headers: { "Content-Type": "application/json", ...options?.headers },
    ...options,
  });

  if (!response.ok) {
    const body = await response.json().catch(() => ({}));
    const detail = (body as { detail?: string }).detail ?? response.statusText;
    throw new Error(detail);
  }

  return response.json() as Promise<T>;
}

/** Run BFS, DFS, A*, or compare all on the same grid */
export function runPathfind(payload: {
  grid: number[][];
  start: Point;
  end: Point;
  algorithm: "bfs" | "dfs" | "astar" | "all";
}): Promise<PathfindResponse> {
  return request<PathfindResponse>("/api/pathfind", {
    method: "POST",
    body: JSON.stringify(payload),
  });
}

/** Optimize delivery stops with Genetic Algorithm */
export function optimizeDelivery(payload: {
  stops: Point[];
  population_size?: number;
  generations?: number;
  mutation_rate?: number;
}): Promise<DeliveryResponse> {
  return request<DeliveryResponse>("/api/delivery/optimize", {
    method: "POST",
    body: JSON.stringify(payload),
  });
}

/** Load pre-built CASE Islamabad timetable demo */
export function loadSampleTimetable(): Promise<TimetableResponse> {
  return request<TimetableResponse>("/api/timetable/sample");
}

/** Health check — useful after Render cold start */
export function checkHealth(): Promise<{ status: string }> {
  return request<{ status: string }>("/api/health");
}

export { API_BASE };
