"""
CampusPath AI — FastAPI Application Entry Point
=================================================
Starts the REST API that powers pathfinding, delivery optimization,
and timetable scheduling modules.

Run locally:
    cd backend
    pip install -r requirements.txt
    uvicorn app.main:app --reload --port 8000

Interactive API docs: http://localhost:8000/docs
"""

from __future__ import annotations

import os

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.api.routes import router

# Allow frontend origins — localhost for dev, env var for production (Vercel)
DEFAULT_ORIGINS = [
    "http://localhost:5173",
    "http://127.0.0.1:5173",
    "http://localhost:4173",
]

extra_origins = os.getenv("CORS_ORIGINS", "")
ALLOWED_ORIGINS = DEFAULT_ORIGINS + [
    origin.strip() for origin in extra_origins.split(",") if origin.strip()
]

app = FastAPI(
    title="CampusPath AI",
    description=(
        "AI-Based Intelligent System for campus navigation, delivery optimization, "
        "and timetable scheduling. Implements BFS, DFS, A*, Genetic Algorithm, and CSP."
    ),
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(router)


@app.get("/")
def root() -> dict[str, str]:
    """Root endpoint with quick links for evaluators."""
    return {
        "message": "CampusPath AI API is running",
        "docs": "/docs",
        "health": "/api/health",
    }
