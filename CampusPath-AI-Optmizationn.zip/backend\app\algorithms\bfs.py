"""
BFS (Breadth-First Search) Pathfinding
======================================
Course topic: Uninformed search
Use case: Shortest path in an unweighted campus grid

How it works:
1. Enqueue the start node in a FIFO queue
2. Dequeue the front node and expand all unvisited neighbors
3. The first time we dequeue the goal, we have the shortest path (by steps)

Why BFS finds the shortest path on unweighted graphs:
  - Nodes are explored in order of increasing distance from start
  - All edges cost 1, so layer-by-layer expansion guarantees optimality

Time complexity: O(V + E) where V = cells, E = edges between cells
Space complexity: O(V) for queue and visited set
"""

from __future__ import annotations

import time
from collections import deque

from .graph import PathResult, neighbors, reconstruct_path, validate_grid_request


def bfs(
    grid: list[list[int]],
    start: tuple[int, int],
    end: tuple[int, int],
) -> PathResult:
    """
    Run BFS from `start` to `end` on a 2D obstacle grid.

    Returns:
        PathResult with shortest path (if found), visit order, and metrics.
    """
    validate_grid_request(grid, start, end)
    t0 = time.perf_counter()

    # FIFO queue — explore closest nodes first
    queue: deque[tuple[int, int]] = deque([start])
    came_from: dict[tuple[int, int], tuple[int, int] | None] = {start: None}
    visited_order: list[tuple[int, int]] = []
    nodes_expanded = 0

    while queue:
        current = queue.popleft()
        nodes_expanded += 1
        visited_order.append(current)

        # Goal test: first dequeue of end guarantees shortest path
        if current == end:
            elapsed = (time.perf_counter() - t0) * 1000
            path = reconstruct_path(came_from, start, end)
            return PathResult(
                path=path,
                visited_order=visited_order,
                nodes_expanded=nodes_expanded,
                time_ms=round(elapsed, 3),
                found=True,
            )

        for nxt in neighbors(current, grid):
            if nxt not in came_from:
                came_from[nxt] = current
                queue.append(nxt)

    elapsed = (time.perf_counter() - t0) * 1000
    return PathResult(
        path=[],
        visited_order=visited_order,
        nodes_expanded=nodes_expanded,
        time_ms=round(elapsed, 3),
        found=False,
    )
