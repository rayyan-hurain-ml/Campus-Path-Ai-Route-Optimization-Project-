/** Algorithm comparison chart — dark neon theme */

import {
  Bar,
  BarChart,
  CartesianGrid,
  Legend,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import type { PathfindMetrics } from "../api/client";
import { CHART, tooltipStyle } from "../lib/chartTheme";

interface MetricsChartProps {
  results: PathfindMetrics[];
}

export function MetricsChart({ results }: MetricsChartProps) {
  const data = results.map((r) => ({
    name: r.algorithm,
    nodes: r.nodes_expanded,
    pathLength: r.path_length,
    timeMs: r.time_ms,
  }));

  if (data.length === 0) return null;

  return (
    <div className="glass rounded-2xl p-5">
      <div className="mb-4 flex items-center justify-between">
        <h3 className="text-sm font-semibold tracking-wide text-white uppercase">
          Algorithm Performance
        </h3>
        <span className="text-[10px] text-slate-500">Nodes expanded vs path length</span>
      </div>
      <div className="h-64">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data} barGap={4}>
            <CartesianGrid strokeDasharray="3 3" stroke={CHART.grid} vertical={false} />
            <XAxis dataKey="name" tick={{ fontSize: 11, fill: CHART.axis }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fontSize: 11, fill: CHART.axis }} axisLine={false} tickLine={false} />
            <Tooltip contentStyle={tooltipStyle} />
            <Legend wrapperStyle={{ fontSize: 11, color: CHART.axis }} />
            <Bar
              dataKey="nodes"
              name="Nodes expanded"
              fill={CHART.cyan}
              radius={[6, 6, 0, 0]}
              style={{ filter: `drop-shadow(0 0 6px ${CHART.cyanGlow})` }}
            />
            <Bar
              dataKey="pathLength"
              name="Path length"
              fill={CHART.lime}
              radius={[6, 6, 0, 0]}
              style={{ filter: "drop-shadow(0 0 6px rgba(163,255,0,0.4))" }}
            />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
