# CampusPath AI Frontend

See the main [README](../README.md) and [DEPLOY](../docs/DEPLOY.md) for setup and deployment.

```powershell
npm install
npm run dev
```

Set `VITE_API_URL` in `.env` for production (see `.env.example`).
