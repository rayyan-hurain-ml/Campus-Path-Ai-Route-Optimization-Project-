/**
 * DeliveryOptimizer — Tab 2 (Dark Dashboard UI)
 */

import { useMemo, useState } from "react";
import {
  Area,
  AreaChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import type { DeliveryResponse, Point } from "../api/client";
import { optimizeDelivery } from "../api/client";
import {
  MapGrid,
  createEmptyGrid,
  pointKey,
  toSet,
  type GridMode,
} from "../components/MapGrid";
import { Alert, Button, Card, KpiRow, ModePill, PageHeader, Stat } from "../components/ui";
import { DeliveryResultExplanation } from "../components/ResultExplanation";
import { EmptyState, InfoBox, StepGuide } from "../components/StepGuide";
import { CHART, tooltipStyle } from "../lib/chartTheme";

const DELIVERY_STEPS = [
  { step: 1, title: "Add stops", description: "Click 'Load Demo Stops' or click the grid to place delivery locations. First stop (green) is the depot." },
  { step: 2, title: "Tune GA settings", description: "Adjust population size, generations, and mutation rate using the sliders." },
  { step: 3, title: "Run optimizer", description: "Click 'Run Genetic Algorithm' — the backend evolves better routes over many generations." },
  { step: 4, title: "Read the explanation", description: "A plain-English summary appears automatically — distance saved, visit order, and why the route is better." },
];

const ROWS = 14;
const COLS = 18;

export function DeliveryOptimizer() {
  const [grid] = useState(() => createEmptyGrid(ROWS, COLS));
  const [stops, setStops] = useState<Point[]>([{ row: 2, col: 2 }]);
  const [mode, setMode] = useState<GridMode>("stop");
  const [populationSize, setPopulationSize] = useState(80);
  const [generations, setGenerations] = useState(120);
  const [mutationRate, setMutationRate] = useState(0.15);
  const [result, setResult] = useState<DeliveryResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const pathSet = useMemo(() => {
    if (!result) return new Set<string>();
    return toSet(result.best_route);
  }, [result]);

  function handleCellClick(row: number, col: number) {
    if (mode !== "stop") return;
    setStops((prev) => {
      const exists = prev.findIndex((s) => s.row === row && s.col === col);
      if (exists >= 0) return prev.filter((_, i) => i !== exists);
      if (prev.length >= 12) return prev;
      return [...prev, { row, col }];
    });
    setResult(null);
  }

  async function handleOptimize() {
    if (stops.length < 2) {
      setError("Add at least 2 stops (depot + one delivery point).");
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const response = await optimizeDelivery({
        stops,
        population_size: populationSize,
        generations,
        mutation_rate: mutationRate,
      });
      setResult(response);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Optimization failed");
    } finally {
      setLoading(false);
    }
  }

  function loadDemoStops() {
    setStops([
      { row: 2, col: 2 },
      { row: 2, col: 14 },
      { row: 6, col: 8 },
      { row: 10, col: 4 },
      { row: 11, col: 15 },
      { row: 5, col: 16 },
    ]);
    setResult(null);
  }

  const fitnessData =
    result?.fitness_history.map((f, i) => ({ generation: i + 1, fitness: f })) ?? [];

  return (
    <div className="space-y-6">
      <PageHeader
        badge="Evolutionary Computation"
        title="Delivery Optimizer"
        description="Genetic Algorithm finds a near-optimal visit order for campus delivery stops. First stop is the depot. Compare optimized route vs naive click order."
      />

      <StepGuide
        steps={DELIVERY_STEPS}
        tip="In viva: explain chromosome = visit order, fitness = 1/(1+distance), and operators = tournament selection + crossover + mutation."
      />

      <InfoBox title="What this module does">
        Models campus delivery as a Traveling Salesperson Problem (TSP). The Genetic Algorithm starts
        with random routes, then evolves better ones using selection, crossover, and mutation over
        many generations until it finds a near-optimal visit order.
      </InfoBox>

      {result && (
        <KpiRow>
          <Stat label="GA Distance" value={result.total_distance} accent="cyan" />
          <Stat label="Naive Distance" value={result.naive_distance} accent="magenta" />
          <Stat label="Improvement" value={`${result.improvement_percent}%`} accent="lime" />
          <Stat label="Runtime" value={`${result.time_ms} ms`} accent="orange" />
        </KpiRow>
      )}

      {error && <Alert message={error} />}

      <div className="flex flex-wrap gap-2">
        <ModePill active={mode === "stop"} onClick={() => setMode("stop")}>
          Add / Remove Stop
        </ModePill>
        <Button variant="outline" size="sm" onClick={loadDemoStops}>
          Load Demo Stops
        </Button>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => {
            setStops([{ row: 2, col: 2 }]);
            setResult(null);
          }}
        >
          Reset
        </Button>
      </div>

      <div className="grid gap-6 xl:grid-cols-[1.3fr_1fr]">
        <MapGrid
          grid={grid}
          rows={ROWS}
          cols={COLS}
          start={stops[0] ?? null}
          end={null}
          stops={stops}
          mode={mode}
          pathSet={pathSet}
          onCellClick={handleCellClick}
          title="Delivery Stops Map"
        />

        <div className="space-y-4">
          <Card title="GA Parameters" subtitle="Tune evolutionary search">
            <Slider
              label="Population size"
              value={populationSize}
              min={20}
              max={200}
              onChange={setPopulationSize}
            />
            <Slider
              label="Generations"
              value={generations}
              min={30}
              max={300}
              onChange={setGenerations}
            />
            <Slider
              label="Mutation rate"
              value={mutationRate}
              min={0.05}
              max={0.4}
              step={0.01}
              onChange={setMutationRate}
            />
            <Button className="mt-4 w-full" loading={loading} onClick={handleOptimize}>
              Run Genetic Algorithm
            </Button>
          </Card>

          <Card title="Active Stops" subtitle={`${stops.length} locations placed`}>
            <p className="font-mono text-xs text-slate-500">
              {stops.map((s, i) => `${i === 0 ? "Depot" : `#${i}`}(${s.row},${s.col})`).join(" · ")}
            </p>
          </Card>
        </div>
      </div>

      {result && (
        <>
          <DeliveryResultExplanation result={result} />

          <div className="glass rounded-2xl p-5">
            <div className="mb-4 flex items-center justify-between">
              <h3 className="text-sm font-semibold tracking-wide text-white uppercase">
                Fitness Over Generations
              </h3>
              <span className="text-[10px] text-[#a3ff00]">
                ↑ {result.generations} generations · pop {result.population_size}
              </span>
            </div>
            <div className="h-56">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={fitnessData}>
                  <defs>
                    <linearGradient id="fitnessGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor={CHART.cyan} stopOpacity={0.4} />
                      <stop offset="100%" stopColor={CHART.cyan} stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke={CHART.grid} vertical={false} />
                  <XAxis dataKey="generation" tick={{ fontSize: 10, fill: CHART.axis }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fontSize: 10, fill: CHART.axis }} axisLine={false} tickLine={false} />
                  <Tooltip contentStyle={tooltipStyle} />
                  <Area
                    type="monotone"
                    dataKey="fitness"
                    stroke={CHART.cyan}
                    strokeWidth={2}
                    fill="url(#fitnessGrad)"
                    style={{ filter: `drop-shadow(0 0 4px ${CHART.cyanGlow})` }}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          <Card title="Optimized Visit Order" subtitle="Best chromosome after evolution">
            <p className="font-mono text-xs leading-relaxed text-slate-400">
              Indices:{" "}
              <span className="text-[#ff007a]">{result.best_order.join(" → ")}</span>
              <br />
              Route: {result.best_route.map((p) => pointKey(p)).join(" → ")}
            </p>
          </Card>
        </>
      )}

      {!result && !loading && (
        <EmptyState
          icon="🚚"
          title="No optimization run yet"
          description="Add at least 2 stops (depot + delivery point), then click Run Genetic Algorithm to see the optimized route and fitness chart."
        />
      )}
    </div>
  );
}

function Slider({
  label,
  value,
  min,
  max,
  step = 1,
  onChange,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  step?: number;
  onChange: (v: number) => void;
}) {
  return (
    <label className="mb-4 block">
      <div className="mb-2 flex justify-between text-xs">
        <span className="text-slate-400">{label}</span>
        <span className="font-semibold text-[#00f2ea]">
          {step < 1 ? value.toFixed(2) : value}
        </span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="w-full"
      />
    </label>
  );
}
