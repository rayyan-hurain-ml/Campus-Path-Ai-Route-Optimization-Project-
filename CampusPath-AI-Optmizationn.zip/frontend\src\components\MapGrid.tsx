/**
 * MapGrid — Interactive 2D Grid (Dark Neon Theme)
 */

import type { Point } from "../api/client";

export type GridMode = "obstacle" | "start" | "end" | "stop";

interface MapGridProps {
  grid: number[][];
  rows: number;
  cols: number;
  start: Point | null;
  end: Point | null;
  stops?: Point[];
  mode: GridMode;
  visitedSet?: Set<string>;
  pathSet?: Set<string>;
  onCellClick: (row: number, col: number) => void;
  title?: string;
}

function key(row: number, col: number): string {
  return `${row},${col}`;
}

export function MapGrid({
  grid,
  rows,
  cols,
  start,
  end,
  stops = [],
  mode,
  visitedSet,
  pathSet,
  onCellClick,
  title = "Campus Grid",
}: MapGridProps) {
  return (
    <div className="glass-strong rounded-2xl p-5">
      <div className="mb-4 flex items-center justify-between">
        <div>
          <h3 className="text-sm font-semibold tracking-wide text-white uppercase">{title}</h3>
          <p className="mt-0.5 text-[10px] text-slate-500">Click cells to interact · Mode below</p>
        </div>
        <span className="rounded-full border border-[rgba(0,242,234,0.3)] bg-[rgba(0,242,234,0.08)] px-3 py-1 text-[10px] font-semibold tracking-wider text-[#00f2ea] uppercase">
          {mode}
        </span>
      </div>

      <div
        className="mx-auto grid gap-[2px] rounded-xl border border-white/5 bg-[rgba(0,0,0,0.4)] p-3"
        style={{
          gridTemplateColumns: `repeat(${cols}, minmax(0, 1fr))`,
          maxWidth: "100%",
          width: "fit-content",
        }}
      >
        {Array.from({ length: rows }).map((_, row) =>
          Array.from({ length: cols }).map((__, col) => {
            const cellKey = key(row, col);
            const isObstacle = grid[row]?.[col] === 1;
            const isStart = start?.row === row && start?.col === col;
            const isEnd = end?.row === row && end?.col === col;
            const stopIndex = stops.findIndex((s) => s.row === row && s.col === col);
            const isVisited = visitedSet?.has(cellKey);
            const isPath = pathSet?.has(cellKey);

            let style = "bg-[rgba(255,255,255,0.04)] grid-cell";
            if (isObstacle) style = "bg-[#1a1f2e] grid-cell grid-cell-obstacle border border-white/5";
            else if (isPath) style = "bg-[#ff8c42] grid-cell shadow-[0_0_8px_rgba(255,140,66,0.6)]";
            else if (isVisited) style = "bg-[rgba(0,242,234,0.15)] grid-cell";
            else if (isStart) style = "bg-[#a3ff00] grid-cell shadow-[0_0_10px_rgba(163,255,0,0.5)]";
            else if (isEnd) style = "bg-[#ff007a] grid-cell shadow-[0_0_10px_rgba(255,0,122,0.5)]";
            else if (stopIndex >= 0)
              style =
                stopIndex === 0
                  ? "bg-[#a3ff00] grid-cell shadow-[0_0_8px_rgba(163,255,0,0.4)]"
                  : "bg-[#7928ca] grid-cell shadow-[0_0_8px_rgba(121,40,202,0.4)]";

            return (
              <button
                key={cellKey}
                type="button"
                aria-label={`Cell ${row},${col}`}
                className={`h-7 w-7 rounded-[3px] transition-all sm:h-8 sm:w-8 ${style}`}
                onClick={() => onCellClick(row, col)}
              >
                {stopIndex > 0 && (
                  <span className="text-[9px] font-bold text-white drop-shadow">{stopIndex}</span>
                )}
              </button>
            );
          }),
        )}
      </div>

      <div className="mt-4 flex flex-wrap gap-4 text-[10px] text-slate-500">
        <Legend color="bg-[#a3ff00]" glow label="Start / Depot" />
        <Legend color="bg-[#ff007a]" glow label="End" />
        <Legend color="bg-[#1a1f2e]" label="Obstacle" />
        <Legend color="bg-[rgba(0,242,234,0.3)]" label="Visited" />
        <Legend color="bg-[#ff8c42]" glow label="Path" />
        <Legend color="bg-[#7928ca]" label="Delivery stop" />
      </div>
    </div>
  );
}

function Legend({ color, label, glow }: { color: string; label: string; glow?: boolean }) {
  return (
    <span className="inline-flex items-center gap-1.5">
      <span
        className={`inline-block h-2.5 w-2.5 rounded-sm ${color} ${glow ? "shadow-[0_0_6px_currentColor]" : ""}`}
      />
      {label}
    </span>
  );
}

export function createEmptyGrid(rows: number, cols: number): number[][] {
  return Array.from({ length: rows }, () => Array(cols).fill(0));
}

export function createCaseCampusPreset(rows: number, cols: number): number[][] {
  const grid = createEmptyGrid(rows, cols);
  for (let c = 5; c < cols - 2; c++) {
    if (c !== 10 && c !== 18) grid[8][c] = 1;
  }
  for (let r = 3; r < rows - 3; r++) {
    if (r !== 6 && r !== 12) grid[r][14] = 1;
  }
  return grid;
}

export function pointKey(p: Point): string {
  return key(p.row, p.col);
}

export function toSet(points: Point[]): Set<string> {
  return new Set(points.map((p) => pointKey(p)));
}
