/** Collapsible step-by-step guide panel shown on each module page */

import { useState, type ReactNode } from "react";

export interface GuideStep {
  step: number;
  title: string;
  description: string;
}

interface StepGuideProps {
  title?: string;
  steps: GuideStep[];
  tip?: string;
  defaultOpen?: boolean;
}

export function StepGuide({
  title = "How to Use This Module",
  steps,
  tip,
  defaultOpen = true,
}: StepGuideProps) {
  const [open, setOpen] = useState(defaultOpen);

  return (
    <div className="glass rounded-2xl border border-[rgba(0,242,234,0.12)] overflow-hidden">
      <button
        type="button"
        onClick={() => setOpen(!open)}
        className="flex w-full items-center justify-between px-5 py-4 text-left transition-colors hover:bg-white/[0.02]"
      >
        <div className="flex items-center gap-3">
          <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-[rgba(0,242,234,0.12)] text-sm text-[#00f2ea]">
            ?
          </span>
          <div>
            <p className="text-sm font-semibold text-white">{title}</p>
            <p className="text-[10px] text-slate-500">{steps.length} steps · Click to {open ? "collapse" : "expand"}</p>
          </div>
        </div>
        <span className={`text-slate-500 transition-transform ${open ? "rotate-180" : ""}`}>▾</span>
      </button>

      {open && (
        <div className="border-t border-white/5 px-5 pb-5 pt-4">
          <ol className="space-y-3">
            {steps.map((s) => (
              <li key={s.step} className="flex gap-3">
                <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-[rgba(0,242,234,0.15)] text-[10px] font-bold text-[#00f2ea]">
                  {s.step}
                </span>
                <div>
                  <p className="text-xs font-semibold text-white">{s.title}</p>
                  <p className="mt-0.5 text-xs leading-relaxed text-slate-400">{s.description}</p>
                </div>
              </li>
            ))}
          </ol>
          {tip && (
            <div className="mt-4 rounded-xl border border-[rgba(163,255,0,0.2)] bg-[rgba(163,255,0,0.05)] px-4 py-3">
              <p className="text-[10px] font-semibold tracking-wider text-[#a3ff00] uppercase">Pro tip</p>
              <p className="mt-1 text-xs text-slate-400">{tip}</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

/** Info box explaining what a module does */
export function InfoBox({ title, children }: { title: string; children: ReactNode }) {
  return (
    <div className="rounded-xl border border-[rgba(255,0,122,0.15)] bg-[rgba(255,0,122,0.04)] px-4 py-3">
      <p className="text-[10px] font-semibold tracking-wider text-[#ff007a] uppercase">{title}</p>
      <div className="mt-1.5 text-xs leading-relaxed text-slate-400">{children}</div>
    </div>
  );
}

/** Empty state when no results yet */
export function EmptyState({ icon, title, description }: { icon: string; title: string; description: string }) {
  return (
    <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed border-white/10 bg-white/[0.02] px-6 py-10 text-center">
      <span className="text-3xl">{icon}</span>
      <p className="mt-3 text-sm font-semibold text-white">{title}</p>
      <p className="mt-1 max-w-sm text-xs text-slate-500">{description}</p>
    </div>
  );
}
