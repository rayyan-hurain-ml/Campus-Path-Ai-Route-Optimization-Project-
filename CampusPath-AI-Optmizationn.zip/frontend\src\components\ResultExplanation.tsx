/**
 * ResultExplanation — Automatic plain-language explanation when output appears.
 * Shows a simple summary for everyone, plus optional technical details for viva.
 */

import { useState, type ReactNode } from "react";
import type { DeliveryResponse, PathfindMetrics, TimetableResponse } from "../api/client";

function PlainSummary({ text }: { text: string }) {
  return (
    <div className="mb-4 rounded-xl border border-[rgba(163,255,0,0.22)] bg-gradient-to-br from-[rgba(163,255,0,0.08)] to-transparent p-4">
      <p className="mb-2 text-[10px] font-semibold tracking-widest text-[#a3ff00] uppercase">
        In Simple Words — What Just Happened
      </p>
      <p className="text-sm leading-relaxed text-slate-100">{text}</p>
    </div>
  );
}

function ExplainBlock({
  step,
  title,
  simple,
  technical,
  showTechnical,
}: {
  step: number;
  title: string;
  simple: string;
  technical?: string;
  showTechnical: boolean;
}) {
  return (
    <div className="rounded-xl border border-white/5 bg-white/[0.02] p-4">
      <div className="mb-2 flex items-center gap-2">
        <span className="flex h-6 w-6 items-center justify-center rounded-full bg-[rgba(0,242,234,0.15)] text-[10px] font-bold text-[#00f2ea]">
          {step}
        </span>
        <p className="text-xs font-semibold text-white">{title}</p>
      </div>
      <p className="text-xs leading-relaxed text-slate-300">{simple}</p>
      {showTechnical && technical && (
        <p className="mt-2 border-t border-white/5 pt-2 text-[11px] leading-relaxed text-slate-500">
          <span className="font-semibold text-[#ff007a]">Technical detail: </span>
          {technical}
        </p>
      )}
    </div>
  );
}

function ExplanationPanel({
  icon,
  title,
  subtitle,
  accentClass,
  borderClass,
  summary,
  children,
}: {
  icon: string;
  title: string;
  subtitle: string;
  accentClass: string;
  borderClass: string;
  summary: string;
  children: ReactNode | ((showTechnical: boolean) => ReactNode);
}) {
  const [showTechnical, setShowTechnical] = useState(false);

  return (
    <div className={`glass rounded-2xl border ${borderClass} p-5`}>
      <div className="mb-4 flex flex-wrap items-start justify-between gap-3">
        <div className="flex items-center gap-2">
          <span className="text-lg">{icon}</span>
          <div>
            <p className={`text-sm font-semibold ${accentClass}`}>{title}</p>
            <p className="text-[10px] text-slate-500">{subtitle}</p>
          </div>
        </div>
        <button
          type="button"
          onClick={() => setShowTechnical((v) => !v)}
          className="rounded-full border border-white/10 bg-white/[0.03] px-3 py-1.5 text-[10px] font-semibold text-slate-400 transition-colors hover:border-white/20 hover:text-white"
        >
          {showTechnical ? "Hide technical details" : "Show technical details (for viva)"}
        </button>
      </div>

      <PlainSummary text={summary} />

      <div className="space-y-3">
        {typeof children === "function" ? children(showTechnical) : children}
      </div>
    </div>
  );
}

function buildPathfindSummary(results: PathfindMetrics[], active: PathfindMetrics): string {
  if (!active.found) {
    return "The computer tried to find a walking route from your green start point to the pink end point, but the dark walls block every possible path. Remove some walls or move the start/end points, then run again.";
  }

  const optimalLen = Math.min(...results.filter((r) => r.found).map((r) => r.path_length));
  const isShortest = active.path_length === optimalLen;
  const compared = results.length > 1;

  let summary = `The app sent your campus map to the backend and ran ${active.algorithm}. `;
  summary += `It found a route of ${active.path_length} steps after checking ${active.nodes_expanded} squares on the map (took ${active.time_ms} ms). `;
  summary += `On the grid, light blue shows where the computer looked; orange shows the final path you would walk. `;

  if (isShortest) {
    summary += `This is the shortest possible route on this map.`;
  } else {
    summary += `This route works, but it is not the shortest — the best route here needs ${optimalLen} steps.`;
  }

  if (compared && results.length >= 2) {
    const bfs = results.find((r) => r.algorithm === "BFS");
    const astar = results.find((r) => r.algorithm === "A*");
    if (bfs?.found && astar?.found && astar.nodes_expanded < bfs.nodes_expanded) {
      summary += ` Compared to BFS, A* checked ${bfs.nodes_expanded - astar.nodes_expanded} fewer squares while still finding a good path — like searching smarter, not harder.`;
    }
  }

  return summary;
}

export function PathfindResultExplanation({
  results,
  activeAlgo,
}: {
  results: PathfindMetrics[];
  activeAlgo: string;
}) {
  const active = results.find((r) => r.algorithm === activeAlgo) ?? results[0];
  if (!active) return null;

  const bfs = results.find((r) => r.algorithm === "BFS");
  const dfs = results.find((r) => r.algorithm === "DFS");
  const astar = results.find((r) => r.algorithm === "A*");

  const optimalLen = Math.min(...results.filter((r) => r.found).map((r) => r.path_length));
  const isOptimal = active.found && active.path_length === optimalLen;

  let comparison = "";
  if (results.length >= 2 && bfs && astar && bfs.found && astar.found) {
    if (astar.nodes_expanded < bfs.nodes_expanded) {
      comparison = `A* checked ${bfs.nodes_expanded - astar.nodes_expanded} fewer squares than BFS but still found a route of ${optimalLen} steps. That means it searched more efficiently.`;
    } else {
      comparison = `Both BFS and A* found a route of ${optimalLen} steps. Compare how many squares each one checked in the chart above.`;
    }
  }
  if (dfs && active.algorithm === "DFS" && dfs.found && dfs.path_length > optimalLen) {
    comparison = `DFS found a route of ${dfs.path_length} steps, but the shortest route is ${optimalLen} steps. DFS sometimes picks a longer path because it goes deep in one direction before trying other options.`;
  }

  const algoExplain: Record<string, { simple: string; technical: string }> = {
    BFS: {
      simple: `BFS works like ripples in water — it checks nearby squares first, then moves outward layer by layer. It found a ${active.path_length}-step route after checking ${active.nodes_expanded} squares.`,
      technical: `BFS uses a FIFO queue. On unweighted grids, the first time the goal is dequeued, path length equals minimum steps. Time: O(V+E).`,
    },
    DFS: {
      simple: `DFS picks one direction and goes as far as possible before turning back — like exploring a maze by always taking the first turn. It found a ${active.path_length}-step route after checking ${active.nodes_expanded} squares.`,
      technical: `DFS expands depth-first via LIFO stack. No optimality guarantee on unweighted graphs. Time: O(V+E).`,
    },
    "A*": {
      simple: `A* is a smarter search: it prefers squares that are closer to the goal, so it usually checks fewer places than BFS. It found a ${active.path_length}-step route after checking ${active.nodes_expanded} squares in ${active.time_ms} ms.`,
      technical: `A* uses f(n)=g(n)+h(n) with Manhattan heuristic h(n). Admissible on grids → optimal path; typically fewer expansions than BFS.`,
    },
  };

  const exp = algoExplain[active.algorithm] ?? algoExplain.BFS;
  const summary = buildPathfindSummary(results, active);

  return (
    <ExplanationPanel
      icon="📊"
      title="Automatic Result Explanation"
      subtitle="Plain summary + step-by-step breakdown (appears after every run)"
      accentClass="text-[#00f2ea]"
      borderClass="border-[rgba(0,242,234,0.15)]"
      summary={summary}
    >
      {(showTechnical) => (
        <>
          <ExplainBlock
            step={1}
            title="Your map was sent to the backend"
            simple="The app took your grid, green start point, and pink end point and sent them to the Python server. The server treats each open square as a place you can walk to, connected up/down/left/right."
            technical="Grid graph G=(V,E). Each cell (row,col) is a vertex. Edges connect orthogonal walkable neighbors."
            showTechnical={showTechnical}
          />

          <ExplainBlock
            step={2}
            title={`${active.algorithm} searched for a route`}
            simple={exp.simple}
            technical={exp.technical}
            showTechnical={showTechnical}
          />

          <ExplainBlock
            step={3}
            title="Results came back to the screen"
            simple={`The server returned the final path (${active.path.length} squares), every square it checked (${active.visited_order.length} total), and the numbers shown in the stats above.`}
            technical={`PathResult: path[], visited_order[], nodes_expanded=${active.nodes_expanded}, time_ms=${active.time_ms}, found=${active.found}`}
            showTechnical={showTechnical}
          />

          <ExplainBlock
            step={4}
            title="What you should take away"
            simple={
              active.found
                ? isOptimal
                  ? `${active.algorithm} found the shortest route (${active.path_length} steps). ${comparison || "Use the chart above to compare how much work each algorithm did."}`
                  : `${active.algorithm} found a working route, but the shortest on this map is ${optimalLen} steps.`
                : "No route exists — walls completely block travel from start to end. Try removing walls or moving the points."
            }
            technical={
              active.found
                ? `Optimality: ${isOptimal ? "Yes" : "No"}. nodes_expanded measures search efficiency.`
                : "Unreachable goal: no walkable path connects start to end."
            }
            showTechnical={showTechnical}
          />
        </>
      )}
    </ExplanationPanel>
  );
}

function buildDeliverySummary(result: DeliveryResponse): string {
  const saved = result.naive_distance - result.total_distance;
  const stopCount = result.best_order.length;

  return (
    `You placed ${stopCount} delivery stops (green depot is stop 0). ` +
    `If a person visits them in the order you clicked, total travel distance is ${result.naive_distance.toFixed(1)} units. ` +
    `The Genetic Algorithm tried many different visit orders over ${result.generations} rounds and found a smarter sequence with distance ${result.total_distance.toFixed(1)} — ` +
    `about ${result.improvement_percent}% shorter (saved ${saved.toFixed(1)} units). ` +
    `The green line on the map shows that optimized route. Think of it like reordering errands so you drive less between stops.`
  );
}

export function DeliveryResultExplanation({ result }: { result: DeliveryResponse }) {
  const saved = result.naive_distance - result.total_distance;

  return (
    <ExplanationPanel
      icon="🧬"
      title="Automatic Result Explanation"
      subtitle="Plain summary + step-by-step breakdown (appears after every run)"
      accentClass="text-[#a3ff00]"
      borderClass="border-[rgba(163,255,0,0.15)]"
      summary={buildDeliverySummary(result)}
    >
      {(showTechnical) => (
        <>
          <ExplainBlock
            step={1}
            title="The delivery problem"
            simple={`You have ${result.best_order.length} stops. The delivery person starts at the depot (stop 0), visits every stop once, and returns. The goal is to pick the visit order with the smallest total walking distance.`}
            technical="TSP variant: minimize Σ Manhattan distance over permutations of stops, return to depot."
            showTechnical={showTechnical}
          />

          <ExplainBlock
            step={2}
            title="First: the simple (unchanged) order"
            simple={`Before any smart search, the app measured distance ${result.naive_distance.toFixed(1)} for visiting stops exactly in the order you placed them. This is the baseline to beat.`}
            technical="naive_order = click order. naive_distance = route_distance(stops, naive_order)."
            showTechnical={showTechnical}
          />

          <ExplainBlock
            step={3}
            title="Then: the Genetic Algorithm improved the order"
            simple={`The computer created ${result.population_size} random routes, kept the best ones, mixed pairs together, and swapped stops randomly — repeating this ${result.generations} times. The fitness chart shows the score getting better each generation.`}
            technical="Fitness = 1/(1+distance). Tournament selection, Order Crossover (OX), swap mutation, elitism."
            showTechnical={showTechnical}
          />

          <ExplainBlock
            step={4}
            title="Final optimized route"
            simple={`Best distance = ${result.total_distance.toFixed(1)} (saved ${saved.toFixed(1)} vs naive). Improvement = ${result.improvement_percent}%. Visit order by stop number: ${result.best_order.join(" → ")}.`}
            technical={`Heuristic GA — near-optimal, not guaranteed global optimum. Runtime: ${result.time_ms} ms.`}
            showTechnical={showTechnical}
          />

          <ExplainBlock
            step={5}
            title="Why this matters in real life"
            simple={`On campus, a courier visiting ${result.best_order.length} places in the optimized order travels about ${result.improvement_percent}% less — less time walking, less fatigue, faster deliveries.`}
            technical="Multi-stop routing is NP-hard. GA gives a fast approximate solution for real-time logistics."
            showTechnical={showTechnical}
          />
        </>
      )}
    </ExplanationPanel>
  );
}

function buildTimetableSummary(result: TimetableResponse): string {
  if (!result.found) {
    return "The scheduler tried every possible way to place the courses into time slots and rooms, but no conflict-free timetable exists with the current data. A teacher or room would be double-booked, or a room would be too small.";
  }

  return (
    `The app scheduled all ${result.assignments.length} courses into days, time slots, and rooms with zero conflicts. ` +
    `No teacher teaches two classes at the same time, no room is used twice at once, and every room is big enough for its class size. ` +
    `The computer tried ${result.nodes_explored} partial arrangements in ${result.time_ms} ms before finding this valid timetable. ` +
    `The table below shows exactly where each course goes — like an auto-generated weekly schedule for CASE Islamabad.`
  );
}

export function TimetableResultExplanation({ result }: { result: TimetableResponse }) {
  return (
    <ExplanationPanel
      icon="📅"
      title="Automatic Result Explanation"
      subtitle="Plain summary + step-by-step breakdown (appears after every run)"
      accentClass="text-[#ff007a]"
      borderClass="border-[rgba(255,0,122,0.15)]"
      summary={buildTimetableSummary(result)}
    >
      {(showTechnical) => (
        <>
          <ExplainBlock
            step={1}
            title="What needed to be scheduled"
            simple="Five courses each need a day, a time slot, and a room. Every course must fit in a room that holds enough students."
            technical="Variables X = {c1..c5}. Domain D(c) = valid (slot, room) pairs with capacity ≥ enrollment."
            showTechnical={showTechnical}
          />

          <ExplainBlock
            step={2}
            title="Rules that must never break"
            simple="Before placing any course, the solver checks: the teacher is free at that time, the room is free at that time, and the room is large enough."
            technical="Hard constraints: unique (teacher, slot), unique (room, slot), capacity(room) ≥ enrollment."
            showTechnical={showTechnical}
          />

          <ExplainBlock
            step={3}
            title="How the computer searched"
            simple={`It tried placing one course at a time. When a clash appeared, it undid that choice and tried the next option — like solving a puzzle by trial and error. It explored ${result.nodes_explored} partial tries in ${result.time_ms} ms.`}
            technical="Backtracking with forward checking. nodes_explored counts recursive assignment attempts."
            showTechnical={showTechnical}
          />

          <ExplainBlock
            step={4}
            title="The final timetable"
            simple={
              result.found
                ? `All ${result.assignments.length} courses are placed with no clashes. Each cell in the grid shows course name, teacher, and room.`
                : "No valid complete timetable exists for this input."
            }
            technical={
              result.found
                ? `found=true. Satisfied: ${result.satisfied_constraints.length} constraint groups.`
                : "CSP unsatisfiable under current courses, rooms, and slots."
            }
            showTechnical={showTechnical}
          />

          <ExplainBlock
            step={5}
            title="Why this matters in real life"
            simple="Making timetables by hand is slow and easy to get wrong. This system guarantees no double-booked teachers or rooms — useful for any university or school."
            technical="CSP backtracking is complete: finds a solution if one exists, otherwise proves none exists."
            showTechnical={showTechnical}
          />
        </>
      )}
    </ExplanationPanel>
  );
}
