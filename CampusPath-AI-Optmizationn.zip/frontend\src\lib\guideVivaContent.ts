/** Project rationale content for Guide page */

export const WHY_CHOSE = {
  project: [
    "Combines 5 AI topics in one cohesive real-world story",
    "Live visual dashboard is clearer than console-only output",
    "Direct performance comparison (BFS vs DFS vs A*) on the same map",
    "Sample campus maps and timetable data included for quick testing",
    "Scalable architecture — can deploy free on Render + Vercel",
  ],
  algorithms: [
    { algo: "BFS", why: "Baseline for shortest path — proves optimality, easy to explain" },
    { algo: "DFS", why: "Contrast with BFS — shows uninformed search limitations" },
    { algo: "A*", why: "Shows power of heuristics — same optimal path, fewer nodes" },
    { algo: "Genetic Algorithm", why: "Handles NP-hard multi-stop routing where simple search fails" },
    { algo: "CSP", why: "Models logical reasoning and constraint checking — different AI paradigm" },
  ],
} as const;
