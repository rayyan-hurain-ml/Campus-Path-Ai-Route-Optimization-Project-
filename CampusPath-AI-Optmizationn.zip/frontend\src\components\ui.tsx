/** Reusable UI — dark glassmorphism + neon accents (fintech / data-center style) */

import type { ButtonHTMLAttributes, ReactNode } from "react";

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "primary" | "secondary" | "ghost" | "outline";
  loading?: boolean;
  size?: "sm" | "md";
}

export function Button({
  variant = "primary",
  loading,
  children,
  className = "",
  disabled,
  size = "md",
  ...props
}: ButtonProps) {
  const base =
    "inline-flex items-center justify-center rounded-full font-medium transition-all duration-200 disabled:cursor-not-allowed disabled:opacity-40";
  const sizes = {
    sm: "px-3 py-1.5 text-xs",
    md: "px-5 py-2.5 text-sm",
  };
  const variants = {
    primary:
      "bg-[#00f2ea] text-[#050810] hover:bg-[#33f5ee] glow-cyan font-semibold",
    secondary:
      "glass text-slate-200 hover:border-[rgba(0,242,234,0.3)] hover:text-[#00f2ea]",
    ghost: "text-slate-400 hover:bg-white/5 hover:text-white",
    outline:
      "border border-[rgba(0,242,234,0.35)] text-[#00f2ea] hover:bg-[rgba(0,242,234,0.08)]",
  };

  return (
    <button
      className={`${base} ${sizes[size]} ${variants[variant]} ${className}`}
      disabled={disabled || loading}
      {...props}
    >
      {loading ? (
        <span className="flex items-center gap-2">
          <span className="h-3 w-3 animate-spin rounded-full border-2 border-current border-t-transparent" />
          Processing…
        </span>
      ) : (
        children
      )}
    </button>
  );
}

export function Card({
  title,
  subtitle,
  children,
  className = "",
}: {
  title: string;
  subtitle?: string;
  children: ReactNode;
  className?: string;
}) {
  return (
    <div className={`glass rounded-2xl p-5 ${className}`}>
      <div className="mb-4 flex items-start justify-between gap-2">
        <div>
          <h3 className="text-sm font-semibold tracking-wide text-white uppercase">{title}</h3>
          {subtitle && <p className="mt-0.5 text-xs text-slate-500">{subtitle}</p>}
        </div>
        <div className="h-px flex-1 self-center bg-gradient-to-r from-[rgba(0,242,234,0.3)] to-transparent" />
      </div>
      {children}
    </div>
  );
}

export function Stat({
  label,
  value,
  accent = "cyan",
  trend,
}: {
  label: string;
  value: string | number;
  accent?: "cyan" | "magenta" | "lime" | "orange";
  trend?: string;
}) {
  const accentStyles = {
    cyan: {
      wrap: "from-[rgba(0,242,234,0.15)] to-transparent border-[rgba(0,242,234,0.2)]",
      text: "text-[#00f2ea]",
    },
    magenta: {
      wrap: "from-[rgba(255,0,122,0.15)] to-transparent border-[rgba(255,0,122,0.2)]",
      text: "text-[#ff007a]",
    },
    lime: {
      wrap: "from-[rgba(163,255,0,0.12)] to-transparent border-[rgba(163,255,0,0.2)]",
      text: "text-[#a3ff00]",
    },
    orange: {
      wrap: "from-[rgba(255,140,66,0.15)] to-transparent border-[rgba(255,140,66,0.2)]",
      text: "text-[#ff8c42]",
    },
  };
  const a = accentStyles[accent];

  return (
    <div className={`glass rounded-xl border bg-gradient-to-br px-4 py-3 ${a.wrap}`}>
      <p className="text-[10px] font-medium tracking-widest text-slate-500 uppercase">{label}</p>
      <p className={`mt-1 text-2xl font-bold ${a.text}`}>{value}</p>
      {trend && <p className="mt-0.5 text-xs text-slate-500">{trend}</p>}
    </div>
  );
}

export function Alert({
  message,
  type = "error",
}: {
  message: string;
  type?: "error" | "info" | "success";
}) {
  const styles = {
    error: "border-[rgba(255,0,122,0.3)] bg-[rgba(255,0,122,0.08)] text-[#ff6b9d]",
    info: "border-[rgba(0,242,234,0.3)] bg-[rgba(0,242,234,0.06)] text-[#00f2ea]",
    success: "border-[rgba(163,255,0,0.3)] bg-[rgba(163,255,0,0.06)] text-[#a3ff00]",
  };
  return (
    <div className={`rounded-xl border px-4 py-3 text-sm ${styles[type]}`}>{message}</div>
  );
}

/** Page header with title + description — matches reference dashboard headers */
export function PageHeader({
  title,
  description,
  badge,
}: {
  title: string;
  description: string;
  badge?: string;
}) {
  return (
    <div className="mb-6">
      {badge && (
        <span className="mb-2 inline-block rounded-full border border-[rgba(0,242,234,0.25)] bg-[rgba(0,242,234,0.08)] px-3 py-0.5 text-[10px] font-semibold tracking-widest text-[#00f2ea] uppercase">
          {badge}
        </span>
      )}
      <h2 className="text-2xl font-bold tracking-tight text-white glow-text-cyan">{title}</h2>
      <p className="mt-1.5 max-w-2xl text-sm leading-relaxed text-slate-400">{description}</p>
    </div>
  );
}

/** KPI row at top of each tab */
export function KpiRow({ children }: { children: ReactNode }) {
  return <div className="mb-6 grid grid-cols-2 gap-3 md:grid-cols-4">{children}</div>;
}

/** Tool mode pill selector */
export function ModePill({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`rounded-full px-4 py-2 text-xs font-medium transition-all ${
        active
          ? "bg-[rgba(0,242,234,0.15)] text-[#00f2ea] border border-[rgba(0,242,234,0.4)] glow-cyan"
          : "glass text-slate-400 hover:text-white"
      }`}
    >
      {children}
    </button>
  );
}
