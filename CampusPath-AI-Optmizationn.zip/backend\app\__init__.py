"""CampusPath AI backend package."""
