/**
 * TimetableScheduler — Tab 3 (Dark Dashboard UI)
 */

import { useState, type ReactNode } from "react";
import type { TimetableResponse } from "../api/client";
import { loadSampleTimetable } from "../api/client";
import { Alert, Button, Card, KpiRow, PageHeader, Stat } from "../components/ui";
import { TimetableResultExplanation } from "../components/ResultExplanation";
import { EmptyState, InfoBox, StepGuide } from "../components/StepGuide";

const TIMETABLE_STEPS = [
  { step: 1, title: "Load sample data", description: "Click 'Load CASE Islamabad Sample & Solve' — uses 5 courses, 3 rooms, 5 time slots." },
  { step: 2, title: "CSP runs automatically", description: "Backend uses backtracking search to find a conflict-free assignment." },
  { step: 3, title: "View timetable", description: "Grid shows which course is in which room at which time." },
  { step: 4, title: "Read the explanation", description: "A plain-English summary appears automatically — what was scheduled, which rules were kept, and why it matters." },
];

export function TimetableScheduler() {
  const [result, setResult] = useState<TimetableResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleLoadSample() {
    setLoading(true);
    setError(null);
    try {
      const response = await loadSampleTimetable();
      setResult(response);
      if (!response.found) {
        setError("No conflict-free timetable exists for this configuration.");
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Timetable solve failed");
    } finally {
      setLoading(false);
    }
  }

  const days = result ? [...new Set(result.assignments.map((a) => a.day))] : [];
  const slots = result
    ? [...new Set(result.assignments.map((a) => a.slot_label))].sort()
    : [];

  return (
    <div className="space-y-6">
      <PageHeader
        badge="Constraint Satisfaction Problem"
        title="Timetable Scheduler"
        description="CSP backtracking assigns courses to time slots and rooms at Sir Syed CASE Institute without teacher or room conflicts."
      />

      <StepGuide
        steps={TIMETABLE_STEPS}
        tip="Constraints enforced: no teacher double-booking, no room double-booking, room capacity ≥ enrollment."
      />

      <InfoBox title="What this module does">
        A Constraint Satisfaction Problem (CSP) assigns each course to a (day, time slot, room) tuple.
        Backtracking search tries assignments and backtracks when a constraint is violated until a
        complete conflict-free timetable is found.
      </InfoBox>

      {error && <Alert message={error} type={result?.found ? "info" : "error"} />}

      <Button loading={loading} onClick={handleLoadSample}>
        Load CASE Islamabad Sample & Solve
      </Button>

      {!result && !loading && (
        <EmptyState
          icon="📅"
          title="No timetable generated yet"
          description="Click the button above to load CASE Islamabad sample data and solve the CSP. Results will appear here."
        />
      )}

      {result && !result.found && (
        <TimetableResultExplanation result={result} />
      )}

      {result?.found && (
        <>
          <KpiRow>
            <Stat label="Courses" value={result.assignments.length} accent="cyan" />
            <Stat label="Nodes Explored" value={result.nodes_explored} accent="magenta" />
            <Stat label="Solve Time" value={`${result.time_ms} ms`} accent="orange" />
            <Stat label="Status" value="Feasible" accent="lime" />
          </KpiRow>

          <TimetableResultExplanation result={result} />

          <Card title="Timetable Grid" subtitle="Conflict-free schedule output">
            <div className="overflow-x-auto rounded-xl border border-white/5">
              <table className="min-w-full text-left text-sm">
                <thead>
                  <tr className="border-b border-white/5 bg-white/[0.02]">
                    <th className="px-4 py-3 text-[10px] font-semibold tracking-widest text-slate-500 uppercase">
                      Time
                    </th>
                    {days.map((day) => (
                      <th
                        key={day}
                        className="px-4 py-3 text-[10px] font-semibold tracking-widest text-[#00f2ea] uppercase"
                      >
                        {day}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {slots.map((slotLabel) => (
                    <tr key={slotLabel} className="table-row-hover border-b border-white/[0.03]">
                      <td className="px-4 py-3 text-xs font-medium text-slate-400">{slotLabel}</td>
                      {days.map((day) => {
                        const cell = result.assignments.find(
                          (a) => a.day === day && a.slot_label === slotLabel,
                        );
                        return (
                          <td key={`${day}-${slotLabel}`} className="px-3 py-3 align-top">
                            {cell ? (
                              <div className="rounded-xl border border-[rgba(0,242,234,0.15)] bg-gradient-to-br from-[rgba(0,242,234,0.08)] to-transparent p-3">
                                <p className="text-xs font-semibold text-white">{cell.course_name}</p>
                                <p className="mt-0.5 text-[10px] text-[#00f2ea]">{cell.teacher}</p>
                                <p className="mt-0.5 text-[10px] text-slate-500">{cell.room_name}</p>
                              </div>
                            ) : (
                              <span className="text-slate-700">—</span>
                            )}
                          </td>
                        );
                      })}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>

          <div className="grid gap-4 md:grid-cols-2">
            <Card title="Input Data" subtitle="CASE Islamabad sample">
              <div className="grid gap-4 sm:grid-cols-3">
                <DataBlock title="Courses">
                  <li>AI 2101 — Mr. Zeeshan (45)</li>
                  <li>CS 2103 — Dr. Ahmed (40)</li>
                  <li>CS 2201 — Dr. Ahmed (35)</li>
                  <li>SE 3101 — Ms. Fatima (30)</li>
                  <li>CN 3201 — Mr. Bilal (38)</li>
                </DataBlock>
                <DataBlock title="Rooms">
                  <li>Lab A — Block 1 (50)</li>
                  <li>Lecture Hall B (45)</li>
                  <li>Room 204 (35)</li>
                </DataBlock>
                <DataBlock title="Slots">
                  <li>Mon 09:00, Mon 11:00</li>
                  <li>Tue 09:00, Tue 11:00</li>
                  <li>Wed 09:00</li>
                </DataBlock>
              </div>
            </Card>

            <Card title="Satisfied Constraints" subtitle="All hard constraints met">
              <ul className="space-y-2">
                {result.satisfied_constraints.map((c) => (
                  <li key={c} className="flex items-start gap-2 text-xs text-slate-400">
                    <span className="mt-0.5 h-1.5 w-1.5 shrink-0 rounded-full bg-[#a3ff00] shadow-[0_0_6px_rgba(163,255,0,0.6)]" />
                    {c}
                  </li>
                ))}
              </ul>
            </Card>
          </div>
        </>
      )}
    </div>
  );
}

function DataBlock({ title, children }: { title: string; children: ReactNode }) {
  return (
    <div>
      <h4 className="mb-2 text-[10px] font-semibold tracking-widest text-slate-500 uppercase">
        {title}
      </h4>
      <ul className="space-y-1 text-xs text-slate-400">{children}</ul>
    </div>
  );
}
