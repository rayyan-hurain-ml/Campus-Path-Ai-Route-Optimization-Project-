/**
 * PathfindingLab — Tab 1 (Dark Dashboard UI)
 */

import { useMemo, useState } from "react";
import type { PathfindMetrics } from "../api/client";
import { runPathfind } from "../api/client";
import {
  MapGrid,
  createCaseCampusPreset,
  createEmptyGrid,
  pointKey,
  toSet,
  type GridMode,
} from "../components/MapGrid";
import { MetricsChart } from "../components/MetricsChart";
import { PathfindResultExplanation } from "../components/ResultExplanation";
import { EmptyState, InfoBox, StepGuide } from "../components/StepGuide";
import { Alert, Button, Card, KpiRow, ModePill, PageHeader, Stat } from "../components/ui";

const PATHFINDING_STEPS = [
  { step: 1, title: "Load a map", description: "Click 'Load CASE Campus' for a pre-built demo with walls and corridors." },
  { step: 2, title: "Draw obstacles", description: "Select Obstacle mode, then click cells to add or remove walls (dark cells)." },
  { step: 3, title: "Set start & end", description: "Select Start → click green point. Select End → click pink goal." },
  { step: 4, title: "Run algorithms", description: "Click 'Compare All' to run BFS, DFS, and A* on the same map simultaneously." },
  { step: 5, title: "Read the explanation", description: "After each run, a plain-English summary appears automatically below the stats — anyone can understand it." },
];

const ROWS = 16;
const COLS = 22;

export function PathfindingLab() {
  const [grid, setGrid] = useState(() => createEmptyGrid(ROWS, COLS));
  const [start, setStart] = useState<{ row: number; col: number } | null>({ row: 0, col: 0 });
  const [end, setEnd] = useState<{ row: number; col: number } | null>({
    row: ROWS - 1,
    col: COLS - 1,
  });
  const [mode, setMode] = useState<GridMode>("obstacle");
  const [results, setResults] = useState<PathfindMetrics[]>([]);
  const [activeAlgo, setActiveAlgo] = useState<string>("A*");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const activeResult = useMemo(
    () => results.find((r) => r.algorithm === activeAlgo) ?? results[0],
    [results, activeAlgo],
  );

  const visitedSet = useMemo(
    () => (activeResult ? toSet(activeResult.visited_order) : new Set<string>()),
    [activeResult],
  );
  const pathSet = useMemo(
    () => (activeResult?.found ? toSet(activeResult.path) : new Set<string>()),
    [activeResult],
  );

  function handleCellClick(row: number, col: number) {
    if (mode === "obstacle") {
      setGrid((prev) => {
        const next = prev.map((r) => [...r]);
        next[row][col] = next[row][col] === 1 ? 0 : 1;
        return next;
      });
      return;
    }
    if (mode === "start") {
      setStart({ row, col });
      setGrid((prev) => {
        const next = prev.map((r) => [...r]);
        next[row][col] = 0;
        return next;
      });
    }
    if (mode === "end") {
      setEnd({ row, col });
      setGrid((prev) => {
        const next = prev.map((r) => [...r]);
        next[row][col] = 0;
        return next;
      });
    }
  }

  async function handleRun(algorithm: "bfs" | "dfs" | "astar" | "all") {
    if (!start || !end) {
      setError("Set both start and end points on the grid.");
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const response = await runPathfind({ grid, start, end, algorithm });
      setResults(response.results);
      setActiveAlgo(response.results[0]?.algorithm ?? "A*");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Pathfinding failed");
    } finally {
      setLoading(false);
    }
  }

  function loadPreset() {
    setGrid(createCaseCampusPreset(ROWS, COLS));
    setStart({ row: 0, col: 0 });
    setEnd({ row: ROWS - 1, col: COLS - 1 });
    setResults([]);
  }

  function clearGrid() {
    setGrid(createEmptyGrid(ROWS, COLS));
    setStart({ row: 0, col: 0 });
    setEnd({ row: ROWS - 1, col: COLS - 1 });
    setResults([]);
  }

  const isOptimal =
    activeResult?.found &&
    results.some((r) => r.found) &&
    activeResult.path_length ===
      Math.min(...results.filter((r) => r.found).map((r) => r.path_length));

  return (
    <div className="space-y-6">
      <PageHeader
        badge="Uninformed + Informed Search"
        title="Pathfinding Lab"
        description="Compare BFS, DFS, and A* on the same campus grid. Paint obstacles, set start/end, then run algorithms to analyze search efficiency and path optimality."
      />

      <StepGuide
        steps={PATHFINDING_STEPS}
        tip="For your report: screenshot the bar chart after Compare All — it shows nodes expanded vs path length for all three algorithms."
      />

      <InfoBox title="What this module does">
        Simulates campus navigation on a 2D grid. Each cell is a location; obstacles block movement.
        BFS finds shortest path (guaranteed). DFS explores deep first (may not be optimal).
        A* uses a heuristic to find optimal path with fewer expanded nodes.
      </InfoBox>

      {activeResult && (
        <KpiRow>
          <Stat label="Algorithm" value={activeResult.algorithm} accent="cyan" />
          <Stat label="Path Length" value={activeResult.path_length} accent="lime" />
          <Stat label="Nodes Expanded" value={activeResult.nodes_expanded} accent="magenta" />
          <Stat label="Runtime" value={`${activeResult.time_ms} ms`} accent="orange" />
        </KpiRow>
      )}

      {error && <Alert message={error} />}

      <div className="flex flex-wrap gap-2">
        {(["obstacle", "start", "end"] as GridMode[]).map((m) => (
          <ModePill key={m} active={mode === m} onClick={() => setMode(m)}>
            {m.charAt(0).toUpperCase() + m.slice(1)}
          </ModePill>
        ))}
        <Button variant="outline" size="sm" onClick={loadPreset}>
          Load CASE Campus
        </Button>
        <Button variant="ghost" size="sm" onClick={clearGrid}>
          Clear Grid
        </Button>
      </div>

      <div className="grid gap-6 xl:grid-cols-[1.4fr_1fr]">
        <MapGrid
          grid={grid}
          rows={ROWS}
          cols={COLS}
          start={start}
          end={end}
          mode={mode}
          visitedSet={visitedSet}
          pathSet={pathSet}
          onCellClick={handleCellClick}
          title="Interactive Campus Grid"
        />

        <div className="space-y-4">
          <Card title="Run Algorithms" subtitle="Execute search on current map">
            <div className="flex flex-wrap gap-2">
              <Button loading={loading} onClick={() => handleRun("all")}>
                Compare All
              </Button>
              <Button variant="secondary" size="sm" loading={loading} onClick={() => handleRun("bfs")}>
                BFS
              </Button>
              <Button variant="secondary" size="sm" loading={loading} onClick={() => handleRun("dfs")}>
                DFS
              </Button>
              <Button variant="secondary" size="sm" loading={loading} onClick={() => handleRun("astar")}>
                A*
              </Button>
            </div>

            {results.length > 0 && (
              <div className="mt-4 flex flex-wrap gap-2 border-t border-white/5 pt-4">
                {results.map((r) => (
                  <ModePill
                    key={r.algorithm}
                    active={activeAlgo === r.algorithm}
                    onClick={() => setActiveAlgo(r.algorithm)}
                  >
                    View {r.algorithm}
                  </ModePill>
                ))}
              </div>
            )}
          </Card>

          {activeResult && (
            <Card title="Analysis" subtitle={`Viewing ${activeResult.algorithm} results`}>
              <div className="grid grid-cols-2 gap-3">
                <Stat label="Found" value={activeResult.found ? "Yes" : "No"} accent="lime" />
                <Stat label="Optimal?" value={isOptimal ? "Yes" : "No"} accent="cyan" />
              </div>
            </Card>
          )}
        </div>
      </div>

      {results.length > 0 && (
        <PathfindResultExplanation results={results} activeAlgo={activeAlgo} />
      )}

      {results.length > 0 && <MetricsChart results={results} />}

      {!activeResult && !loading && (
        <EmptyState
          icon="🗺️"
          title="No results yet"
          description="Load CASE Campus or draw your own map, set start/end points, then click Compare All to see algorithm results here."
        />
      )}

      {activeResult && (
        <Card title="Path Trace" subtitle="Full coordinate sequence">
          <p className="font-mono text-xs leading-relaxed text-slate-400">
            <span className="text-[#00f2ea]">{activeResult.algorithm}</span> →{" "}
            {activeResult.path.length} cells:{" "}
            {activeResult.path.map((p) => pointKey(p)).join(" → ") || "none"}
          </p>
        </Card>
      )}
    </div>
  );
}
