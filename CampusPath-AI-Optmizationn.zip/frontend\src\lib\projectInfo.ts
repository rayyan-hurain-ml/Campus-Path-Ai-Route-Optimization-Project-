/** Project and student information — used across UI and docs */

export const PROJECT = {
  name: "CampusPath AI",
  fullTitle: "CampusPath AI — Smart Route Optimization System",
  subtitle: "AI-Based Intelligent System for Real-World Problems",
  course: "Artificial Intelligence (AI 2101)",
  semester: "Spring 2026 (SP26)",
  institute: "Sir Syed CASE Institute of Technology, Islamabad",
  instructor: "Mr. Muhammad Zeeshan Aslam",
  clo: "CLO4 — Complex Computing Problem",
} as const;

export const STUDENT = {
  name: "Hurain",
  initials: "HU",
  displayLine: "Hurain",
} as const;
