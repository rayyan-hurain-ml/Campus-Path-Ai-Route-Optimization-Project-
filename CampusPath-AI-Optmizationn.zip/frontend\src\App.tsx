/**
 * App — Main Layout
 */

import { useState, type ReactNode } from "react";
import { API_BASE } from "./api/client";
import { PROJECT, STUDENT } from "./lib/projectInfo";
import { DeliveryOptimizer } from "./pages/DeliveryOptimizer";
import { GuidePage } from "./pages/GuidePage";
import { PathfindingLab } from "./pages/PathfindingLab";
import { TimetableScheduler } from "./pages/TimetableScheduler";

type Tab = "pathfinding" | "delivery" | "timetable" | "guide";

const NAV: {
  id: Tab;
  label: string;
  desc: string;
  icon: ReactNode;
  highlight?: boolean;
}[] = [
  {
    id: "guide",
    label: "Guide & Help",
    desc: "Full project documentation",
    icon: <IconGuide />,
    highlight: true,
  },
  {
    id: "pathfinding",
    label: "Pathfinding Lab",
    desc: "BFS · DFS · A*",
    icon: <IconPath />,
  },
  {
    id: "delivery",
    label: "Delivery Optimizer",
    desc: "Genetic Algorithm",
    icon: <IconRoute />,
  },
  {
    id: "timetable",
    label: "Timetable Scheduler",
    desc: "CSP Backtracking",
    icon: <IconCalendar />,
  },
];

const TAB_TITLES: Record<Tab, string> = {
  guide: "PROJECT GUIDE & DOCUMENTATION",
  pathfinding: "PATHFINDING INTELLIGENCE CENTER",
  delivery: "DELIVERY OPTIMIZATION HUB",
  timetable: "SMART TIMETABLE SCHEDULER",
};

export default function App() {
  const [tab, setTab] = useState<Tab>("guide");

  return (
    <div className="relative flex min-h-screen">
      <div className="app-bg" aria-hidden />

      <aside className="relative z-10 flex w-[260px] shrink-0 flex-col border-r border-white/5 glass-strong">
        <div className="border-b border-white/5 px-5 py-6">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-[#00f2ea] to-[#0088ff] text-sm font-black text-[#050810] glow-cyan">
              {STUDENT.initials}
            </div>
            <div>
              <h1 className="text-sm font-bold leading-tight tracking-tight text-white">
                {PROJECT.name}
              </h1>
              <p className="text-[10px] tracking-wider text-[#00f2ea]">{STUDENT.name}</p>
            </div>
          </div>
        </div>

        <nav className="flex-1 space-y-1 p-4">
          <p className="mb-2 px-2 text-[10px] font-semibold tracking-widest text-slate-600 uppercase">
            Navigation
          </p>
          {NAV.map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => setTab(item.id)}
              className={`group flex w-full items-center gap-3 rounded-xl px-3 py-3 text-left transition-all ${
                tab === item.id
                  ? "bg-[rgba(0,242,234,0.1)] border border-[rgba(0,242,234,0.25)] text-white"
                  : item.highlight
                    ? "border border-[rgba(163,255,0,0.15)] text-slate-300 hover:bg-[rgba(163,255,0,0.05)]"
                    : "border border-transparent text-slate-400 hover:bg-white/5 hover:text-white"
              }`}
            >
              <span
                className={`flex h-8 w-8 items-center justify-center rounded-lg transition-all ${
                  tab === item.id
                    ? "bg-[rgba(0,242,234,0.15)] text-[#00f2ea]"
                    : item.highlight
                      ? "bg-[rgba(163,255,0,0.1)] text-[#a3ff00]"
                      : "bg-white/5 text-slate-500 group-hover:text-slate-300"
                }`}
              >
                {item.icon}
              </span>
              <div>
                <p className="text-sm font-medium">{item.label}</p>
                <p className="text-[10px] text-slate-500">{item.desc}</p>
              </div>
            </button>
          ))}
        </nav>

        <div className="m-4 rounded-xl border border-[rgba(0,242,234,0.15)] bg-gradient-to-br from-[rgba(0,242,234,0.08)] to-transparent p-4">
          <p className="text-xs font-semibold text-[#00f2ea]">{PROJECT.course}</p>
          <p className="mt-1 text-[10px] leading-relaxed text-slate-500">
            {STUDENT.name} · 5 AI Algorithms
          </p>
        </div>

        <div className="border-t border-white/5 px-4 py-3">
          <p className="truncate text-[10px] text-slate-600">API: {API_BASE}</p>
        </div>
      </aside>

      <div className="relative z-10 flex flex-1 flex-col overflow-hidden">
        <header className="flex items-center justify-between border-b border-white/5 glass px-6 py-4">
          <div>
            <p className="text-[10px] font-semibold tracking-[0.2em] text-[#00f2ea] uppercase">
              {STUDENT.name}
            </p>
            <h2 className="text-sm font-bold tracking-wide text-white">{TAB_TITLES[tab]}</h2>
          </div>
          <div className="flex items-center gap-3">
            {tab !== "guide" && (
              <button
                type="button"
                onClick={() => setTab("guide")}
                className="hidden rounded-full border border-[rgba(163,255,0,0.25)] bg-[rgba(163,255,0,0.06)] px-3 py-1.5 text-[10px] font-semibold text-[#a3ff00] uppercase transition-colors hover:bg-[rgba(163,255,0,0.12)] sm:block"
              >
                Need Help?
              </button>
            )}
            <div className="flex items-center gap-2 rounded-full border border-[rgba(163,255,0,0.25)] bg-[rgba(163,255,0,0.06)] px-3 py-1.5">
              <span className="status-live h-2 w-2 rounded-full bg-[#a3ff00]" />
              <span className="text-[10px] font-semibold text-[#a3ff00] uppercase">Live</span>
            </div>
          </div>
        </header>

        <main className="flex-1 overflow-auto p-6 md:p-8">
          {tab === "guide" && <GuidePage />}
          {tab === "pathfinding" && <PathfindingLab />}
          {tab === "delivery" && <DeliveryOptimizer />}
          {tab === "timetable" && <TimetableScheduler />}
        </main>
      </div>
    </div>
  );
}

function IconGuide() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <circle cx="12" cy="12" r="10" /><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3" /><path d="M12 17h.01" />
    </svg>
  );
}
function IconPath() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <circle cx="5" cy="5" r="2" /><circle cx="19" cy="19" r="2" />
      <path d="M7 5h3l4 4v3l4 4h3" />
    </svg>
  );
}
function IconRoute() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <path d="M3 12h4l2-5 4 10 2-5h6" />
    </svg>
  );
}
function IconCalendar() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <rect x="3" y="4" width="18" height="18" rx="2" />
      <path d="M16 2v4M8 2v4M3 10h18" />
    </svg>
  );
}
