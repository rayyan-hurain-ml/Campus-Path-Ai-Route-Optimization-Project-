"""
DFS (Depth-First Search) Pathfinding
====================================
Course topic: Uninformed search
Use case: Explore deep paths first; useful for maze exploration / backtracking

How it works:
1. Push start onto a LIFO stack
2. Pop a node and expand unvisited neighbors (push onto stack)
3. Continue until goal found or stack empty

Difference from BFS:
  - DFS goes deep before wide — may find a longer path first
  - Does NOT guarantee shortest path on unweighted graphs
  - Often expands fewer nodes in open maps but can wander in mazes

Time complexity: O(V + E)
Space complexity: O(V) for stack and visited set
"""

from __future__ import annotations

import time

from .graph import PathResult, neighbors, reconstruct_path, validate_grid_request


def dfs(
    grid: list[list[int]],
    start: tuple[int, int],
    end: tuple[int, int],
) -> PathResult:
    """
    Run iterative DFS from `start` to `end`.

    Uses an explicit stack (not recursion) to avoid Python recursion limits
    on large grids.
    """
    validate_grid_request(grid, start, end)
    t0 = time.perf_counter()

    stack: list[tuple[int, int]] = [start]
    came_from: dict[tuple[int, int], tuple[int, int] | None] = {start: None}
    visited_order: list[tuple[int, int]] = []
    nodes_expanded = 0

    while stack:
        current = stack.pop()
        nodes_expanded += 1
        visited_order.append(current)

        if current == end:
            elapsed = (time.perf_counter() - t0) * 1000
            path = reconstruct_path(came_from, start, end)
            return PathResult(
                path=path,
                visited_order=visited_order,
                nodes_expanded=nodes_expanded,
                time_ms=round(elapsed, 3),
                found=True,
            )

        # Push neighbors in reverse so top-to-left feels natural on grid
        for nxt in reversed(neighbors(current, grid)):
            if nxt not in came_from:
                came_from[nxt] = current
                stack.append(nxt)

    elapsed = (time.perf_counter() - t0) * 1000
    return PathResult(
        path=[],
        visited_order=visited_order,
        nodes_expanded=nodes_expanded,
        time_ms=round(elapsed, 3),
        found=False,
    )
