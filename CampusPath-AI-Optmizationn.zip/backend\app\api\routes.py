"""FastAPI route handlers for CampusPath AI."""

from __future__ import annotations

from fastapi import APIRouter, HTTPException

from app.algorithms import astar, bfs, dfs, optimize_delivery_route, solve_timetable
from app.algorithms.csp_timetable import (
    Course,
    Room,
    TimeSlot,
    case_islamabad_sample,
)
from app.models.schemas import (
    AssignmentOutput,
    DeliveryRequest,
    DeliveryResponse,
    PathfindMetrics,
    PathfindRequest,
    PathfindResponse,
    Point,
    TimetableRequest,
    TimetableResponse,
)

router = APIRouter(prefix="/api")


def _to_point(cell: tuple[int, int]) -> Point:
    return Point(row=cell[0], col=cell[1])


def _run_pathfind(
    grid: list[list[int]],
    start: tuple[int, int],
    end: tuple[int, int],
    algorithm: str,
) -> PathfindMetrics:
    """Dispatch to the correct search algorithm and format metrics."""
    if algorithm == "bfs":
        result = bfs(grid, start, end)
    elif algorithm == "dfs":
        result = dfs(grid, start, end)
    elif algorithm == "astar":
        result = astar(grid, start, end)
    else:
        raise ValueError(f"Unknown algorithm: {algorithm}")

    return PathfindMetrics(
        algorithm=algorithm.upper(),
        found=result.found,
        path_length=len(result.path) - 1 if result.found else 0,
        nodes_expanded=result.nodes_expanded,
        time_ms=result.time_ms,
        path=[_to_point(c) for c in result.path],
        visited_order=[_to_point(c) for c in result.visited_order],
    )


@router.get("/health")
def health_check() -> dict[str, str]:
    """Simple health endpoint for deployment smoke tests."""
    return {"status": "ok", "service": "CampusPath AI API"}


@router.post("/pathfind", response_model=PathfindResponse)
def pathfind(request: PathfindRequest) -> PathfindResponse:
    """
    Run BFS, DFS, A*, or compare all three on the same grid.

    The frontend sends a 2D grid (0=free, 1=obstacle) plus start/end cells.
    """
    grid = request.grid
    start = (request.start.row, request.start.col)
    end = (request.end.row, request.end.col)

    algorithms = (
        ["bfs", "dfs", "astar"]
        if request.algorithm == "all"
        else [request.algorithm]
    )

    results: list[PathfindMetrics] = []
    for algo in algorithms:
        try:
            results.append(_run_pathfind(grid, start, end, algo))
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    optimal = min(
        (r.path_length for r in results if r.found),
        default=None,
    )

    return PathfindResponse(results=results, optimal_path_length=optimal)


@router.post("/delivery/optimize", response_model=DeliveryResponse)
def delivery_optimize(request: DeliveryRequest) -> DeliveryResponse:
    """
    Optimize multi-stop delivery route using a Genetic Algorithm.

    Stop index 0 is treated as the depot (start/end).
    """
    stops = [(s.row, s.col) for s in request.stops]

    try:
        result = optimize_delivery_route(
            stops=stops,
            population_size=request.population_size,
            generations=request.generations,
            mutation_rate=request.mutation_rate,
            seed=request.seed,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    improvement = 0.0
    if result.naive_distance > 0:
        improvement = round(
            ((result.naive_distance - result.total_distance) / result.naive_distance) * 100,
            1,
        )

    return DeliveryResponse(
        best_route=[_to_point(c) for c in result.best_route],
        best_order=result.best_order,
        total_distance=result.total_distance,
        naive_distance=result.naive_distance,
        improvement_percent=improvement,
        fitness_history=result.fitness_history,
        generations=result.generations,
        population_size=result.population_size,
        time_ms=result.time_ms,
    )


def _solve_and_format(
    courses: list[Course],
    rooms: list[Room],
    slots: list[TimeSlot],
) -> TimetableResponse:
    result = solve_timetable(courses, rooms, slots)
    return TimetableResponse(
        found=result.found,
        assignments=[AssignmentOutput(**a.__dict__) for a in result.assignments],
        satisfied_constraints=result.satisfied_constraints,
        time_ms=result.time_ms,
        nodes_explored=result.nodes_explored,
    )


@router.get("/timetable/sample", response_model=TimetableResponse)
def timetable_sample() -> TimetableResponse:
    """Return a pre-built CASE Islamabad demo timetable."""
    courses, rooms, slots = case_islamabad_sample()
    return _solve_and_format(courses, rooms, slots)


@router.post("/timetable/solve", response_model=TimetableResponse)
def timetable_solve(request: TimetableRequest) -> TimetableResponse:
    """Solve a custom timetable CSP from user-provided courses, rooms, and slots."""
    courses = [Course(**c.model_dump()) for c in request.courses]
    rooms = [Room(**r.model_dump()) for r in request.rooms]
    slots = [TimeSlot(**s.model_dump()) for s in request.slots]
    return _solve_and_format(courses, rooms, slots)
