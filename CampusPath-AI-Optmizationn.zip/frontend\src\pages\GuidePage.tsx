/**
 * GuidePage — In-App Complete Project Guide
 * Everything: what it is, why, how to run, how to use each module.
 */

import { useState, type ReactNode } from "react";
import { API_BASE } from "../api/client";
import { Card, PageHeader } from "../components/ui";
import { WHY_CHOSE } from "../lib/guideVivaContent";
import { PROJECT, STUDENT } from "../lib/projectInfo";

type Section =
  | "overview"
  | "problem"
  | "run"
  | "pathfinding"
  | "delivery"
  | "timetable"
  | "algorithms";

const SECTIONS: { id: Section; label: string; icon: string }[] = [
  { id: "overview", label: "What Is This?", icon: "◈" },
  { id: "problem", label: "Problem & Solution", icon: "◆" },
  { id: "run", label: "How to Run", icon: "▶" },
  { id: "pathfinding", label: "Pathfinding Lab", icon: "◎" },
  { id: "delivery", label: "Delivery Optimizer", icon: "⬡" },
  { id: "timetable", label: "Timetable Scheduler", icon: "▦" },
  { id: "algorithms", label: "5 Algorithms", icon: "⚙" },
];

export function GuidePage() {
  const [section, setSection] = useState<Section>("overview");

  return (
    <div className="space-y-6">
      <PageHeader
        badge={STUDENT.name}
        title="Guide & Help"
        description={`Complete documentation for ${PROJECT.fullTitle}. Everything explained from scratch — what, why, and how to use each module.`}
      />

      <div className="grid gap-6 lg:grid-cols-[220px_1fr]">
        {/* Section nav */}
        <nav className="glass flex flex-row gap-1 overflow-x-auto rounded-2xl p-2 lg:flex-col lg:overflow-visible">
          {SECTIONS.map((s) => (
            <button
              key={s.id}
              type="button"
              onClick={() => setSection(s.id)}
              className={`flex shrink-0 items-center gap-2 rounded-xl px-3 py-2.5 text-left text-xs transition-all lg:w-full ${
                section === s.id
                  ? "bg-[rgba(0,242,234,0.12)] text-[#00f2ea] border border-[rgba(0,242,234,0.25)]"
                  : "text-slate-400 hover:bg-white/5 hover:text-white"
              }`}
            >
              <span>{s.icon}</span>
              {s.label}
            </button>
          ))}
        </nav>

        {/* Content */}
        <div className="space-y-4">
          {section === "overview" && <OverviewSection />}
          {section === "problem" && <ProblemSection />}
          {section === "run" && <RunSection />}
          {section === "pathfinding" && <PathfindingSection />}
          {section === "delivery" && <DeliverySection />}
          {section === "timetable" && <TimetableSection />}
          {section === "algorithms" && <AlgorithmsSection />}
        </div>
      </div>
    </div>
  );
}

function OverviewSection() {
  return (
    <>
      <GuideCard title="Project Info">
        <div className="grid gap-2 sm:grid-cols-2">
          <InfoRow label="Student Name" value={STUDENT.name} />
          <InfoRow label="Project Name" value={PROJECT.fullTitle} />
        </div>
      </GuideCard>

      <GuideCard title="What Is CampusPath AI?">
        <p>
          CampusPath AI is an <strong className="text-white">intelligent web system</strong> built by{" "}
          <strong className="text-[#00f2ea]">{STUDENT.name}</strong>. It solves three real university
          problems using <strong className="text-[#00f2ea]">five AI algorithms</strong> — more than
          the required minimum of three.
        </p>
      </GuideCard>

      <GuideCard title="Why Was It Built?">
        <ul className="list-inside list-disc space-y-2">
          <li>
            <strong className="text-white">Navigation</strong> — students need shortest walkable routes
            on campus (BFS, DFS, A*)
          </li>
          <li>
            <strong className="text-white">Delivery</strong> — campus mail must visit many buildings
            efficiently (Genetic Algorithm)
          </li>
          <li>
            <strong className="text-white">Timetabling</strong> — courses need rooms and times without
            conflicts (CSP)
          </li>
        </ul>
      </GuideCard>

      <GuideCard title="How Does It Work? (Simple)">
        <div className="space-y-3 font-mono text-xs">
          <FlowStep n={1} text="You click buttons in the browser (React frontend)" />
          <FlowStep n={2} text="Frontend sends data to Python backend (FastAPI)" />
          <FlowStep n={3} text="Backend runs AI algorithms on your input" />
          <FlowStep n={4} text="Results return as JSON → shown on grid, charts, tables" />
        </div>
        <p className="mt-4 text-xs text-slate-500">
          The AI logic never runs in the browser. All algorithms are in{" "}
          <code className="text-[#00f2ea]">backend/app/algorithms/</code>.
        </p>
      </GuideCard>

      <GuideCard title="Project Structure">
        <pre className="overflow-x-auto rounded-xl bg-black/40 p-4 text-[10px] leading-relaxed text-slate-400">
{`backend/             ← Python + all 5 AI algorithms
  app/algorithms/    ← bfs.py dfs.py astar.py GA CSP
frontend/            ← React dashboard (what you see)`}
        </pre>
      </GuideCard>
    </>
  );
}

function RunSection() {
  return (
    <>
      <GuideCard title="How to Run">
        <p className="mb-3">You need two terminals — one for the backend, one for the frontend.</p>
        <ol className="list-inside list-decimal space-y-3">
          <li>
            <strong className="text-white">Backend</strong>
            <pre className="mt-1 overflow-x-auto rounded-lg bg-black/40 p-3 font-mono text-[10px] text-slate-400">
{`cd backend
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000`}
            </pre>
          </li>
          <li>
            <strong className="text-white">Frontend</strong>
            <pre className="mt-1 overflow-x-auto rounded-lg bg-black/40 p-3 font-mono text-[10px] text-slate-400">
{`cd frontend
npm install
npm run dev`}
            </pre>
          </li>
          <li>
            Open <code className="text-[#a3ff00]">http://localhost:5173</code> in your browser
          </li>
        </ol>
      </GuideCard>

      <GuideCard title="Automatic Output Explanations">
        <p className="text-xs leading-relaxed text-slate-400">
          After you run any module (Pathfinding, Delivery, or Timetable), a green{" "}
          <strong className="text-[#a3ff00]">In Simple Words</strong> box appears automatically.
          It explains the result in plain English so a non-technical person can understand what
          happened — no coding knowledge needed. Click{" "}
          <strong className="text-white">Show technical details</strong> for a deeper breakdown.
        </p>
      </GuideCard>

      <GuideCard title="Requirements (Install Once)">
        <ul className="space-y-2">
          <li>
            <strong className="text-white">Python 3.11+</strong> —{" "}
            <a href="https://python.org" className="text-[#00f2ea] hover:underline" target="_blank" rel="noreferrer">
              python.org
            </a>
          </li>
          <li>
            <strong className="text-white">Node.js 18+</strong> —{" "}
            <a href="https://nodejs.org" className="text-[#00f2ea] hover:underline" target="_blank" rel="noreferrer">
              nodejs.org
            </a>
          </li>
        </ul>
      </GuideCard>

      <GuideCard title="Important URLs">
        <ul className="space-y-2 font-mono text-xs">
          <li>
            <span className="text-slate-500">App: </span>
            <span className="text-[#a3ff00]">http://localhost:5173</span>
          </li>
          <li>
            <span className="text-slate-500">API: </span>
            <span className="text-[#00f2ea]">{API_BASE}</span>
          </li>
          <li>
            <span className="text-slate-500">API Docs: </span>
            <span className="text-[#00f2ea]">{API_BASE}/docs</span>
          </li>
        </ul>
      </GuideCard>
    </>
  );
}

function PathfindingSection() {
  return (
    <>
      <GuideCard title="What It Does">
        Finds path from Start (green) to End (pink) on a 2D grid, avoiding obstacles.
        Compares <strong className="text-[#00f2ea]">BFS</strong>,{" "}
        <strong className="text-[#ff007a]">DFS</strong>, and{" "}
        <strong className="text-[#a3ff00]">A*</strong> on the same map.
      </GuideCard>
      <GuideCard title="Step-by-Step">
        <StepList
          steps={[
            "Click Load CASE Campus for a sample map with walls",
            "Select Obstacle mode → click cells to draw/remove walls",
            "Select Start → click where path should begin (green)",
            "Select End → click goal cell (pink)",
            "Click Compare All — all three algorithms run",
            "Cyan cells = explored, Orange = final path",
            "Read KPI cards: path length, nodes expanded, time",
            "Read the automatic plain-English explanation that appears below the stats",
            "View bar chart to compare algorithm efficiency",
          ]}
        />
      </GuideCard>
      <GuideCard title="Key Takeaways">
        BFS guarantees shortest path on unweighted grids. DFS goes deep first and may not be optimal.
        A* uses Manhattan heuristic — optimal like BFS but usually expands fewer nodes.
      </GuideCard>
    </>
  );
}

function DeliverySection() {
  return (
    <>
      <GuideCard title="What It Does">
        Optimizes visit order for multiple campus delivery stops using a{" "}
        <strong className="text-[#00f2ea]">Genetic Algorithm</strong> (evolutionary computation).
        Compares optimized route vs naive click order.
      </GuideCard>
      <GuideCard title="Step-by-Step">
        <StepList
          steps={[
            "Click Load Demo Stops OR click grid to add stops",
            "First stop (green) = depot — delivery starts and ends here",
            "Adjust Population, Generations, Mutation sliders",
            "Click Run Genetic Algorithm",
            "View improvement % and fitness chart over generations",
            "Orange path on grid = best route found",
          ]}
        />
      </GuideCard>
      <GuideCard title="GA Parameters">
        <ul className="space-y-1 text-xs">
          <li><strong className="text-white">Population</strong> — number of random routes per generation</li>
          <li><strong className="text-white">Generations</strong> — how many evolution cycles</li>
          <li><strong className="text-white">Mutation</strong> — random changes for exploration</li>
        </ul>
      </GuideCard>
    </>
  );
}

function TimetableSection() {
  return (
    <>
      <GuideCard title="What It Does">
        Assigns courses to time slots and rooms using{" "}
        <strong className="text-[#00f2ea]">CSP backtracking</strong>. Ensures no teacher or room
        conflicts and room capacity fits enrollment.
      </GuideCard>
      <GuideCard title="Step-by-Step">
        <StepList
          steps={[
            "Click Load CASE Islamabad Sample & Solve",
            "Backend runs CSP on 5 courses, 3 rooms, 5 slots",
            "View timetable grid — courses in day × time cells",
            "Read satisfied constraints list",
            "Note nodes explored and solve time in KPI cards",
          ]}
        />
      </GuideCard>
      <GuideCard title="Constraints Enforced">
        <ul className="list-inside list-disc space-y-1">
          <li>No teacher teaches two classes at same time</li>
          <li>No room hosts two classes at same time</li>
          <li>Room capacity ≥ course enrollment</li>
          <li>Each course assigned exactly once</li>
        </ul>
      </GuideCard>
    </>
  );
}

function AlgorithmsSection() {
  const algos = [
    { name: "BFS", type: "Uninformed Search", file: "bfs.py", desc: "Queue-based layer expansion. Shortest path guaranteed." },
    { name: "DFS", type: "Uninformed Search", file: "dfs.py", desc: "Stack-based deep exploration. May not be optimal." },
    { name: "A*", type: "Informed Search", file: "astar.py", desc: "f(n)=g(n)+h(n) with Manhattan heuristic. Optimal + efficient." },
    { name: "Genetic Algorithm", type: "Optimization", file: "genetic_algorithm.py", desc: "Evolve routes via selection, crossover, mutation." },
    { name: "CSP", type: "Constraint Reasoning", file: "csp_timetable.py", desc: "Backtracking search with constraint checking." },
  ];

  return (
    <>
      <GuideCard title="All 5 Algorithms (Course Requirement: 3)">
        <div className="space-y-3">
          {algos.map((a) => (
            <div
              key={a.name}
              className="rounded-xl border border-white/5 bg-white/[0.02] p-3"
            >
              <div className="flex items-center justify-between">
                <span className="font-semibold text-[#00f2ea]">{a.name}</span>
                <span className="text-[10px] text-slate-500">{a.type}</span>
              </div>
              <p className="mt-1 text-xs text-slate-400">{a.desc}</p>
              <p className="mt-1 font-mono text-[10px] text-slate-600">
                backend/app/algorithms/{a.file}
              </p>
            </div>
          ))}
        </div>
      </GuideCard>
      <GuideCard title="Suggested Code Reading Order">
        <ol className="list-inside list-decimal space-y-1 text-xs">
          <li>graph.py — shared grid utilities</li>
          <li>bfs.py → dfs.py → astar.py — compare search strategies</li>
          <li>genetic_algorithm.py — evolution loop</li>
          <li>csp_timetable.py — backtracking</li>
          <li>api/routes.py — how API calls algorithms</li>
        </ol>
      </GuideCard>
    </>
  );
}

function ProblemSection() {
  return (
    <>
      <GuideCard title="Main Problem (Real World)">
        <p className="mb-3">
          Every day at a university, three problems happen that are classic{" "}
          <strong className="text-white">Artificial Intelligence problems</strong>:
        </p>
        <div className="space-y-3">
          <ProblemBlock
            n={1}
            title="Campus Navigation"
            problem="A student needs the shortest walkable route from Block A to Library, avoiding construction walls."
            solution="Model campus as 2D grid graph. Run BFS (guaranteed shortest), DFS (exploration), A* (heuristic optimal) and compare efficiency."
          />
          <ProblemBlock
            n={2}
            title="Multi-Stop Delivery"
            problem="Campus delivery must visit 6 buildings. Wrong visit order wastes time and distance."
            solution="Model as TSP (Traveling Salesperson Problem). Genetic Algorithm evolves near-optimal visit order over generations."
          />
          <ProblemBlock
            n={3}
            title="Class Timetabling"
            problem="5 courses, 3 rooms, 5 slots. Dr. Ahmed cannot teach two classes simultaneously. Room 204 fits only 35 students."
            solution="Model as CSP. Backtracking search assigns (course → slot, room) satisfying all hard constraints."
          />
        </div>
      </GuideCard>

      <GuideCard title="Why I Chose This Project">
        <ul className="space-y-2">
          {WHY_CHOSE.project.map((reason) => (
            <li key={reason} className="flex gap-2">
              <span className="text-[#a3ff00]">→</span>
              <span>{reason}</span>
            </li>
          ))}
        </ul>
      </GuideCard>

      <GuideCard title="Why These 5 Algorithms?">
        <div className="space-y-2">
          {WHY_CHOSE.algorithms.map((a) => (
            <div key={a.algo} className="rounded-lg bg-white/[0.02] px-3 py-2">
              <span className="font-semibold text-[#00f2ea]">{a.algo}</span>
              <span className="text-slate-500"> — </span>
              <span>{a.why}</span>
            </div>
          ))}
        </div>
      </GuideCard>

      <GuideCard title="My Solution Architecture (Simple)">
        <FlowStep n={1} text="You interact with React dashboard (draw grid, add stops, click buttons)" />
        <FlowStep n={2} text="Frontend sends JSON to Python FastAPI backend via REST API" />
        <FlowStep n={3} text="Backend runs AI algorithm from scratch (no black-box libraries)" />
        <FlowStep n={4} text="Results return → grid visualization + charts + automatic step-by-step explanation" />
      </GuideCard>
    </>
  );
}

function InfoRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg bg-white/[0.02] px-3 py-2">
      <p className="text-[10px] text-slate-500">{label}</p>
      <p className="text-xs font-semibold text-white">{value}</p>
    </div>
  );
}

function ProblemBlock({
  n,
  title,
  problem,
  solution,
}: {
  n: number;
  title: string;
  problem: string;
  solution: string;
}) {
  return (
    <div className="rounded-xl border border-white/5 p-3">
      <p className="text-xs font-semibold text-white">
        {n}. {title}
      </p>
      <p className="mt-1 text-xs text-[#ff007a]">
        <strong>Problem:</strong> {problem}
      </p>
      <p className="mt-1 text-xs text-[#a3ff00]">
        <strong>My Solution:</strong> {solution}
      </p>
    </div>
  );
}

/* Sub-components */
function GuideCard({ title, children }: { title: string; children: ReactNode }) {
  return (
    <Card title={title} subtitle="">
      <div className="text-xs leading-relaxed text-slate-400">{children}</div>
    </Card>
  );
}

function FlowStep({ n, text }: { n: number; text: string }) {
  return (
    <div className="flex items-center gap-3 rounded-lg bg-white/[0.02] px-3 py-2">
      <span className="text-[#00f2ea]">{n}.</span>
      <span className="text-slate-400">{text}</span>
      {n < 4 && <span className="ml-auto text-slate-600">↓</span>}
    </div>
  );
}

function StepList({ steps }: { steps: string[] }) {
  return (
    <ol className="space-y-2">
      {steps.map((s, i) => (
        <li key={s} className="flex gap-2">
          <span className="font-bold text-[#00f2ea]">{i + 1}.</span>
          <span>{s}</span>
        </li>
      ))}
    </ol>
  );
}
