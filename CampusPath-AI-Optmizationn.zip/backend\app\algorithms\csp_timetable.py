"""
CSP (Constraint Satisfaction Problem) — Timetable Scheduler
===========================================================
Course topic: Constraint Satisfaction / backtracking search
Use case: Assign university courses to time slots and rooms without conflicts

Variables:
  Each course must be assigned one (day, slot, room) tuple.

Domains:
  All valid combinations of days × slots × rooms from input.

Constraints (hard):
  1. Teacher constraint — a teacher cannot teach two courses at the same time
  2. Room constraint — a room cannot host two courses at the same time
  3. Capacity constraint — room capacity must be >= course enrollment
  4. Uniqueness — each course assigned exactly once

Search strategy:
  Backtracking with forward checking (prune invalid partial assignments early)

Time complexity: O(d^n) worst case; forward checking reduces practical search space
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field


@dataclass
class Course:
    """A course that needs a timetable slot."""

    id: str
    name: str
    teacher: str
    enrollment: int


@dataclass
class Room:
    """A physical room with capacity limit."""

    id: str
    name: str
    capacity: int


@dataclass
class TimeSlot:
    """A schedulable time block."""

    day: str
    slot: str
    label: str


@dataclass
class Assignment:
    """One course placed in a specific slot and room."""

    course_id: str
    course_name: str
    teacher: str
    day: str
    slot: str
    slot_label: str
    room_id: str
    room_name: str


@dataclass
class CSPResult:
    """Return type for timetable solver."""

    assignments: list[Assignment]
    satisfied_constraints: list[str]
    time_ms: float
    found: bool
    nodes_explored: int = 0


@dataclass
class _ScheduleState:
    """Internal tracking during backtracking."""

    assignments: dict[str, Assignment] = field(default_factory=dict)
    teacher_busy: set[tuple[str, str, str]] = field(default_factory=set)
    room_busy: set[tuple[str, str, str]] = field(default_factory=set)
    nodes_explored: int = 0


def _domain(
    courses: list[Course],
    rooms: list[Room],
    slots: list[TimeSlot],
) -> dict[str, list[tuple[TimeSlot, Room]]]:
    """
    Build domain for each course: all (slot, room) pairs where capacity fits.
    """
    domain: dict[str, list[tuple[TimeSlot, Room]]] = {}
    for course in courses:
        options: list[tuple[TimeSlot, Room]] = []
        for slot in slots:
            for room in rooms:
                if room.capacity >= course.enrollment:
                    options.append((slot, room))
        domain[course.id] = options
    return domain


def _is_consistent(
    course: Course,
    slot: TimeSlot,
    room: Room,
    state: _ScheduleState,
) -> bool:
    """
    Check hard constraints for placing `course` at (slot, room).
    """
    key = (slot.day, slot.slot)

    if (course.teacher, slot.day, slot.slot) in state.teacher_busy:
        return False

    if (room.id, slot.day, slot.slot) in state.room_busy:
        return False

    return True


def _apply_assignment(
    course: Course,
    slot: TimeSlot,
    room: Room,
    state: _ScheduleState,
) -> Assignment:
    """Commit assignment and update busy sets."""
    assignment = Assignment(
        course_id=course.id,
        course_name=course.name,
        teacher=course.teacher,
        day=slot.day,
        slot=slot.slot,
        slot_label=slot.label,
        room_id=room.id,
        room_name=room.name,
    )
    state.assignments[course.id] = assignment
    state.teacher_busy.add((course.teacher, slot.day, slot.slot))
    state.room_busy.add((room.id, slot.day, slot.slot))
    return assignment


def _remove_assignment(course_id: str, state: _ScheduleState) -> None:
    """Undo assignment during backtracking."""
    assignment = state.assignments.pop(course_id)
    state.teacher_busy.discard((assignment.teacher, assignment.day, assignment.slot))
    state.room_busy.discard((assignment.room_id, assignment.day, assignment.slot))


def _backtrack(
    courses: list[Course],
    domain: dict[str, list[tuple[TimeSlot, Room]]],
    index: int,
    state: _ScheduleState,
) -> bool:
    """
    Recursive backtracking with most-constrained-variable ordering (fixed input order).
    """
    if index == len(courses):
        return True

    course = courses[index]
    state.nodes_explored += 1

    for slot, room in domain[course.id]:
        if not _is_consistent(course, slot, room, state):
            continue

        _apply_assignment(course, slot, room, state)

        if _backtrack(courses, domain, index + 1, state):
            return True

        _remove_assignment(course.id, state)

    return False


def solve_timetable(
    courses: list[Course],
    rooms: list[Room],
    slots: list[TimeSlot],
) -> CSPResult:
    """
    Solve the university timetable CSP via backtracking.

    Returns conflict-free assignments or found=False if unsatisfiable.
    """
    if not courses:
        raise ValueError("At least one course is required.")

    t0 = time.perf_counter()
    domain = _domain(courses, rooms, slots)

    for course in courses:
        if not domain[course.id]:
            elapsed = (time.perf_counter() - t0) * 1000
            return CSPResult(
                assignments=[],
                satisfied_constraints=[],
                time_ms=round(elapsed, 3),
                found=False,
                nodes_explored=0,
            )

    state = _ScheduleState()
    found = _backtrack(courses, domain, 0, state)
    elapsed = (time.perf_counter() - t0) * 1000

    satisfied = [
        "Each course assigned exactly one slot and room",
        "No teacher double-booked at the same time",
        "No room double-booked at the same time",
        "Room capacity >= course enrollment for every assignment",
    ]

    assignments = list(state.assignments.values()) if found else []
    return CSPResult(
        assignments=assignments,
        satisfied_constraints=satisfied if found else [],
        time_ms=round(elapsed, 3),
        found=found,
        nodes_explored=state.nodes_explored,
    )


def case_islamabad_sample() -> tuple[list[Course], list[Room], list[TimeSlot]]:
    """
    Pre-loaded demo dataset for Sir Syed CASE Institute of Technology, Islamabad.
    Used by the frontend 'Load Sample' button.
    """
    courses = [
        Course(id="c1", name="Artificial Intelligence (AI 2101)", teacher="Mr. Zeeshan", enrollment=45),
        Course(id="c2", name="Data Structures (CS 2103)", teacher="Dr. Ahmed", enrollment=40),
        Course(id="c3", name="Database Systems (CS 2201)", teacher="Dr. Ahmed", enrollment=35),
        Course(id="c4", name="Software Engineering (SE 3101)", teacher="Ms. Fatima", enrollment=30),
        Course(id="c5", name="Computer Networks (CN 3201)", teacher="Mr. Bilal", enrollment=38),
    ]

    rooms = [
        Room(id="r1", name="Lab A — Block 1", capacity=50),
        Room(id="r2", name="Lecture Hall B", capacity=45),
        Room(id="r3", name="Room 204", capacity=35),
    ]

    slots = [
        TimeSlot(day="Mon", slot="s1", label="Mon 09:00–10:30"),
        TimeSlot(day="Mon", slot="s2", label="Mon 11:00–12:30"),
        TimeSlot(day="Tue", slot="s1", label="Tue 09:00–10:30"),
        TimeSlot(day="Tue", slot="s2", label="Tue 11:00–12:30"),
        TimeSlot(day="Wed", slot="s1", label="Wed 09:00–10:30"),
    ]

    return courses, rooms, slots
