"""
Shared Grid Graph Utilities
===========================
Course topic: Graph representation for search algorithms

This module provides the common data structures used by BFS, DFS, and A*.
CampusPath AI models a campus as a 2D grid where:
  - Each cell (row, col) is a node
  - Edges connect orthogonal neighbors (up, down, left, right)
  - Obstacle cells block movement

Coordinate system:
  - row increases downward (like a 2D array)
  - col increases rightward
  - Node = tuple (row, col)
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable


# Orthogonal directions: (delta_row, delta_col)
DIRECTIONS: tuple[tuple[int, int], ...] = (
    (-1, 0),  # up
    (1, 0),   # down
    (0, -1),  # left
    (0, 1),   # right
)


@dataclass(frozen=True)
class PathResult:
    """
    Standard return type for all pathfinding algorithms.

    Attributes:
        path: Ordered list of (row, col) from start to goal (empty if no path).
        visited_order: Cells expanded in the order the algorithm visited them.
        nodes_expanded: Count of cells removed from frontier / explored.
        time_ms: Wall-clock runtime in milliseconds.
        found: True when a valid path was discovered.
    """

    path: list[tuple[int, int]]
    visited_order: list[tuple[int, int]]
    nodes_expanded: int
    time_ms: float
    found: bool


def in_bounds(row: int, col: int, rows: int, cols: int) -> bool:
    """Return True if (row, col) lies inside the grid dimensions."""
    return 0 <= row < rows and 0 <= col < cols


def is_walkable(row: int, col: int, grid: list[list[int]]) -> bool:
    """
    A cell is walkable when it is not an obstacle.
    Grid encoding: 0 = free, 1 = obstacle.
    """
    return grid[row][col] == 0


def neighbors(node: tuple[int, int], grid: list[list[int]]) -> list[tuple[int, int]]:
    """
    Return all valid orthogonal neighbors of `node` that are in bounds and walkable.

    Used by BFS, DFS, and A* during expansion.
    """
    rows, cols = len(grid), len(grid[0])
    row, col = node
    result: list[tuple[int, int]] = []

    for dr, dc in DIRECTIONS:
        nr, nc = row + dr, col + dc
        if in_bounds(nr, nc, rows, cols) and is_walkable(nr, nc, grid):
            result.append((nr, nc))

    return result


def reconstruct_path(
    came_from: dict[tuple[int, int], tuple[int, int] | None],
    start: tuple[int, int],
    goal: tuple[int, int],
) -> list[tuple[int, int]]:
    """
    Walk parent pointers backward from goal to start, then reverse.

    `came_from[child] = parent` records how we first reached each cell.
    """
    if goal not in came_from:
        return []

    current = goal
    path: list[tuple[int, int]] = []

    while current is not None:
        path.append(current)
        current = came_from.get(current)

    path.reverse()
    return path if path and path[0] == start else []


def manhattan_distance(a: tuple[int, int], b: tuple[int, int]) -> int:
    """
    Manhattan heuristic for A* on grid maps.

    Admissible because each step costs 1 and we only move orthogonally.
    Never overestimates true shortest path length.
    """
    return abs(a[0] - b[0]) + abs(a[1] - b[1])


def validate_grid_request(
    grid: list[list[int]],
    start: tuple[int, int],
    end: tuple[int, int],
) -> None:
    """Raise ValueError for malformed pathfinding requests."""
    if not grid or not grid[0]:
        raise ValueError("Grid must not be empty.")

    rows, cols = len(grid), len(grid[0])
    for r, c in (start, end):
        if not in_bounds(r, c, rows, cols):
            raise ValueError(f"Point ({r}, {c}) is outside grid bounds.")
        if not is_walkable(r, c, grid):
            raise ValueError(f"Point ({r}, {c}) is on an obstacle.")

    if start == end:
        raise ValueError("Start and end must be different cells.")


def grid_to_points(grid: Iterable[Iterable[int]]) -> list[list[int]]:
    """Convert nested iterables to a mutable 2D list of ints."""
    return [list(row) for row in grid]
